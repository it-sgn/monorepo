package service

import (
	"context"
	v1 "mall-go/api/organization/service/v1"
	"mall-go/module/organization/service/internal/biz"
	"mall-go/module/organization/service/internal/data"
	"strconv"

	"github.com/go-kratos/kratos/v2/log"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
)

type AssignmentService struct {
	v1.UnimplementedOrganizationServiceServer

	bc   *biz.AssignmentUsecase
	log  *log.Helper
	data *data.Data // ← Tambahkan ini
}

func NewAssignmentService(bc *biz.AssignmentUsecase, data *data.Data, logger log.Logger) *AssignmentService {
	return &AssignmentService{
		bc:   bc,
		data: data,
		log:  log.NewHelper(logger),
	}
}

// func (s *AssignmentService) Assign(ctx context.Context, in *v1.AssignPositionRequest) (*v1.AssignmentResponse, error) {
// 	// Validasi input
// 	if in.EmployeeId == "" || in.PositionId == "" {
// 		return nil, status.Errorf(codes.InvalidArgument, "employee_id and position_id are required")
// 	}

// 	// Konversi PositionId dari string ke int64
// 	posID, err := strconv.ParseInt(in.PositionId, 10, 64)
// 	if err != nil {
// 		return nil, status.Errorf(codes.InvalidArgument, "invalid position_id: %v", err)
// 	}

// 	// Panggil business logic (usecase)
// 	result, err := s.bc.Assign(ctx, &biz.AssignmentData{
// 		EmployeeID: in.EmployeeId,
// 		PositionID: posID,
// 		StartDate:  in.StartDate.AsTime(),
// 	})
// 	if err != nil {
// 		return nil, status.Errorf(codes.Internal, "failed to assign position: %v", err)
// 	}

// 	// Bungkus ke dalam AssignmentResponse (sesuai proto)
// 	resp := &v1.AssignmentResponse{
// 		Assignment: &v1.Assignment{
// 			Id:         result.ID,
// 			EmployeeId: result.EmployeeID,
// 			PositionId: strconv.FormatInt(result.PositionID, 10),
// 			StartDate:  timestamppb.New(result.StartDate),
// 			EndDate:    timestamppb.New(result.EndDate),
// 			CreatedAt:  timestamppb.New(result.CreatedAt),
// 		},
// 	}

//		return resp, nil
//	}
func (s *AssignmentService) AssignPosition(ctx context.Context, req *v1.AssignPositionRequest) (*v1.AssignmentResponse, error) {
	// Validasi request awal
	if req.EmployeeId == "" {
		return nil, status.Errorf(codes.InvalidArgument, "employee_id is required")
	}
	if req.PositionId == "" {
		return nil, status.Errorf(codes.InvalidArgument, "position_id is required")
	}
	if req.StartDate == nil {
		return nil, status.Errorf(codes.InvalidArgument, "start_date is required")
	}

	// Parse PositionId dari string ke int64
	positionID, err := strconv.ParseInt(req.PositionId, 10, 64)
	if err != nil || positionID <= 0 {
		return nil, status.Errorf(codes.InvalidArgument, "invalid position_id format")
	}

	// Mapping ke struct biz layer
	bizReq := &biz.AssignmentData{
		EmployeeID: req.EmployeeId,
		PositionID: positionID,
		StartDate:  req.StartDate.AsTime(),
	}

	// Delegasikan ke usecase (biz logic)
	resp, err := s.bc.Assign(ctx, bizReq)
	if err != nil {
		return nil, err
	}

	return resp, nil
}
