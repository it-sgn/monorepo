package service

import (
	"context"
	"fmt"

	v1 "mall-go/api/organization/service/v1"
	"mall-go/module/organization/service/internal/biz"
	"mall-go/module/organization/service/internal/data"

	"github.com/go-kratos/kratos/v2/log"
	"google.golang.org/protobuf/types/known/timestamppb"
)

type PositionService struct {
	v1.UnimplementedOrganizationServiceServer

	bc   *biz.PositionUsecase
	log  *log.Helper
	data *data.Data // ← Tambahkan ini
}

func NewPositionService(bc *biz.PositionUsecase, data *data.Data, logger log.Logger) *PositionService {
	return &PositionService{
		bc:   bc,
		data: data,
		log:  log.NewHelper(logger),
	}
}

func (s *PositionService) CreatePosition(ctx context.Context, in *v1.CreatePositionRequest) (*v1.PositionResponse, error) {
	b := &v1.CreatePositionRequest{
		PositionCode:        in.PositionCode,
		Name:                in.Name,
		RoleName:            in.RoleName,
		DepartmentCode:      in.DepartmentCode,
		ReportsToPositionId: in.ReportsToPositionId,
	}

	x, err := s.bc.Create(ctx, b)
	if err != nil {
		return nil, err
	}
	if err := s.data.Kafka.PublishEvent(ctx, &biz.Event{
		Type: "create",
		Key:  x.Position.PositionCode,
		Data: fmt.Sprintf(`{"position":"%s","name":"%s"}`, x.Position.PositionCode, x.Position.Name),
	}); err != nil {
		s.log.Warnf("failed to publish event: %v", err)
	}
	return &v1.PositionResponse{
		Position: &v1.Position{
			Id:                  x.Position.Id,
			PositionCode:        x.Position.PositionCode,
			Name:                x.Position.Name,
			RoleName:            x.Position.RoleName,
			DepartmentCode:      x.Position.DepartmentCode,
			ReportsToPositionId: x.Position.ReportsToPositionId,
			CreatedAt:           x.Position.CreatedAt,
			UpdatedAt:           x.Position.UpdatedAt,
			CreatedBy:           x.Position.CreatedBy,
			UpdatedBy:           x.Position.UpdatedBy,
		},
	}, nil
}

func (s *PositionService) UpdatePosition(ctx context.Context, in *v1.UpdatePositionRequest) (*v1.PositionResponse, error) {
	b := &v1.Position{
		PositionCode:        in.PositionCode,
		Name:                in.Name,
		RoleName:            in.RoleName,
		DepartmentCode:      in.DepartmentCode,
		ReportsToPositionId: in.ReportsToPositionId,
	}
	x, err := s.bc.Update(ctx, b)
	if err != nil {
		return nil, err
	}
	return &v1.PositionResponse{
		Position: &v1.Position{
			Id:                  x.Position.Id,
			PositionCode:        x.Position.PositionCode,
			Name:                x.Position.Name,
			RoleName:            x.Position.RoleName,
			DepartmentCode:      x.Position.DepartmentCode,
			ReportsToPositionId: x.Position.ReportsToPositionId,
			CreatedAt:           x.Position.CreatedAt,
			UpdatedAt:           x.Position.UpdatedAt,
			CreatedBy:           x.Position.CreatedBy,
			UpdatedBy:           x.Position.UpdatedBy,
		}}, nil
}
func (s *PositionService) GetPositionID(ctx context.Context, in *v1.GetPositionIDRequest) (*v1.PositionResponse, error) {
	x, err := s.bc.Get(ctx, in.Id)
	if err != nil {
		return nil, err
	}

	return &v1.PositionResponse{
		Position: &v1.Position{
			Id:                  x.Position.Id,
			PositionCode:        x.Position.PositionCode,
			Name:                x.Position.Name,
			RoleName:            x.Position.RoleName,
			DepartmentCode:      x.Position.DepartmentCode,
			ReportsToPositionId: x.Position.ReportsToPositionId,
			CreatedAt:           x.Position.CreatedAt,
			UpdatedAt:           x.Position.UpdatedAt,
			CreatedBy:           x.Position.CreatedBy,
			UpdatedBy:           x.Position.UpdatedBy,
		},
	}, nil
}

func (s *PositionService) GetByCode(ctx context.Context, in *v1.GetPositionRequest) (*v1.PositionResponse, error) {
	x, err := s.bc.GetByCode(ctx, in.PositionCode)
	if err != nil {
		return nil, err
	}
	return &v1.PositionResponse{
		Position: &v1.Position{
			Id:                  x.Position.Id,
			PositionCode:        x.Position.PositionCode,
			Name:                x.Position.Name,
			RoleName:            x.Position.RoleName,
			DepartmentCode:      x.Position.DepartmentCode,
			ReportsToPositionId: x.Position.ReportsToPositionId,
			CreatedAt:           x.Position.CreatedAt,
			UpdatedAt:           x.Position.UpdatedAt,
			CreatedBy:           x.Position.CreatedBy,
			UpdatedBy:           x.Position.UpdatedBy,
		},
	}, nil
}
func (s *PositionService) DeletePosition(ctx context.Context, in *v1.DeletePositionRequest) (*v1.DeletePositionResponse, error) {
	err := s.bc.Delete(ctx, in.Id)
	if err != nil {
		return nil, err
	}
	return &v1.DeletePositionResponse{Success: true}, nil
}

// func (s *PositionService) ListPosition(ctx context.Context, in *v1.ListPositionRequest) (*v1.ListPositionsResponse, error) {
// 	// list di sini harus slice, bukan response
// 	list, total, err := s.bc.List(ctx, int64(in.Pn), int64(in.Psize))
// 	if err != nil {
// 		return nil, err
// 	}

// 	var positions []*v1.Position
// 	for _, x := range list {
// 		positions = append(positions, &v1.Position{
// 			Id:                  x.Position.Id,
// 			PositionCode:        x.Position.PositionCode,
// 			Name:                x.Position.Name,
// 			RoleName:            x.Position.RoleName,
// 			DepartmentCode:      x.Position.DepartmentCode,
// 			ReportsToPositionId: x.Position.ReportsToPositionId,
// 			CreatedAt:           x.Position.CreatedAt,
// 			UpdatedAt:           x.Position.UpdatedAt,
// 			CreatedBy:           x.Position.CreatedBy,
// 			UpdatedBy:           x.Position.UpdatedBy,
// 		})
// 	}

//		return &v1.ListPositionsResponse{
//			Total:     int64(total),
//			Positions: positions,
//		}, nil
//	}
func (s *PositionService) ListPosition(ctx context.Context, in *v1.ListPositionRequest) (*v1.ListPositionsResponse, error) {
	list, total, err := s.bc.List(ctx, int64(in.Pn), int64(in.Psize))
	if err != nil {
		return nil, err
	}

	var positions []*v1.Position
	for _, x := range list {
		positions = append(positions, &v1.Position{
			Id:                  x.ID,
			PositionCode:        x.PositionCode,
			Name:                x.Name,
			RoleName:            x.RoleName,
			DepartmentCode:      x.DepartmentCode,
			ReportsToPositionId: x.ReportsToPositionId,
			CreatedAt:           timestamppb.New(x.CreatedAt),
			UpdatedAt:           timestamppb.New(x.UpdatedAt),
			CreatedBy:           x.CreatedBy,
			UpdatedBy:           x.UpdatedBy,
		})
	}

	return &v1.ListPositionsResponse{
		Total:     int64(total),
		Positions: positions,
	}, nil
}
