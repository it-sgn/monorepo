package data

import (
	"context"
	"encoding/json"
	"fmt"
	"strings"
	"time"

	departmentv1 "mall-go/api/department/service/v1"
	empv1 "mall-go/api/employers/service/v1"
	orgv1 "mall-go/api/organization/service/v1"
	"mall-go/module/attendance-raw/service/internal/biz"

	"github.com/go-kratos/kratos/v2/log"
	"github.com/go-redis/redis/v8"
)

var _ biz.AttendanceRawRepo = (*attendanceRawRepo)(nil)

type attendanceRawRepo struct {
	data             *Data
	log              *log.Helper
	rdb              *redis.Client
	employersClient  empv1.EmployersClient
	departmentClient departmentv1.DepartmentClient
	orgV1Client      orgv1.OrganizationServiceClient
}

func NewAttendanceRawRepo(data *Data, logger log.Logger) biz.AttendanceRawRepo {
	return &attendanceRawRepo{
		data:             data,
		log:              log.NewHelper(log.With(logger, "module", "data/attendance-raw")),
		rdb:              data.rdb,
		employersClient:  data.EmployersClient,
		departmentClient: data.DepartmentClient,
		orgV1Client:      data.OrgV1Client,
	}
}

// func (r *attendanceRawRepo) GetAttendanceRaw(ctx context.Context, karyacodes []string, start, end string) ([]*biz.AttendanceRaw, error) {
// 	if len(karyacodes) == 0 {
// 		return nil, fmt.Errorf("karyacodes cannot be empty")
// 	}

// 	cacheKey := fmt.Sprintf("attendance:raw:%s:%s", strings.Join(karyacodes, ","), start+"-"+end)

// 	// Try cache
// 	if val, err := r.rdb.Get(ctx, cacheKey).Result(); err == nil {
// 		var cached []*biz.AttendanceRaw
// 		jsonErr := json.Unmarshal([]byte(val), &cached)
// 		if jsonErr := json.Unmarshal([]byte(val), &cached); jsonErr == nil {
// 			r.log.Infof("✅ Redis cache hit: %s", cacheKey)
// 			return cached, nil
// 		}
// 		r.log.Warnf("⚠️ Redis unmarshal failed for key [%s]: %v", cacheKey, jsonErr)
// 	} else if err != redis.Nil {
// 		r.log.Errorf("❌ Redis GET error for key [%s]: %v", cacheKey, err)
// 	}

// 	// DB Query
// 	type Result struct {
// 		UserID   string
// 		DeviceIP string
// 		Tgl      string
// 		ClockIn  string
// 		ClockOut string
// 	}
// 	var results []Result

// 	startTime := time.Now()
// 	err := r.data.db.
// 		Table("attendance_log").
// 		Select([]string{
// 			"user_id",
// 			"device_ip",
// 			"TO_CHAR(att_log::date, 'YYYY-MM-DD') AS tgl",
// 			"TO_CHAR(MIN(att_log) FILTER (WHERE status = 0), 'HH24:MI') AS clock_in",
// 			"TO_CHAR(MAX(att_log) FILTER (WHERE status = 1), 'HH24:MI') AS clock_out",
// 		}).
// 		Where("user_id IN ?", karyacodes).
// 		Where("att_log::date BETWEEN ? AND ?", start, end).
// 		Group("user_id, device_ip, att_log::date").
// 		Order("user_id, att_log::date").
// 		Scan(&results).Error
// 	r.log.Infof("🐘 Query executed in %s", time.Since(startTime))

// 	if err != nil {
// 		return nil, fmt.Errorf("gorm query error: %w", err)
// 	}

// 	// Map results
// 	var mapped []*biz.AttendanceRaw
// 	for _, row := range results {
// 		tglParsed, _ := time.Parse("2006-01-02", row.Tgl)
// 		mapped = append(mapped, &biz.AttendanceRaw{
// 			KodeKarya: row.UserID,
// 			Tanggal:   row.Tgl,
// 			Hari:      localizeDayToIndo(tglParsed.Weekday()),
// 			ClockIn:   row.ClockIn,
// 			ClockOut:  row.ClockOut,
// 			DeviceIP:  row.DeviceIP,
// 		})
// 	}

// 	// Save to Redis
// 	if bytes, err := json.Marshal(mapped); err == nil {
// 		if setErr := r.rdb.Set(ctx, cacheKey, bytes, 3*time.Minute).Err(); setErr != nil {
// 			r.log.Warnf("⚠️ Redis SET error [%s]: %v", cacheKey, setErr)
// 		}
// 	} else {
// 		r.log.Warnf("⚠️ Failed to marshal result: %v", err)
// 	}

// 	return mapped, nil
// }

func safeStr(s string) string {
	return strings.TrimSpace(s)
}
func extractKaryaCodes(employers []*empv1.EmployerItem) []string {
	var out []string
	for _, e := range employers {
		out = append(out, strings.TrimSpace(e.KaryaCode))
	}
	return out
}

// func (r *attendanceRawRepo) GetAttendanceDayli(ctx context.Context, dept, start, end string) ([]*biz.DailyAttendanceReport, error) {
// 	if strings.TrimSpace(dept) == "" {
// 		return nil, fmt.Errorf("depart code cannot be empty")
// 	}
// 	if strings.TrimSpace(start) == "" || strings.TrimSpace(end) == "" {
// 		return nil, fmt.Errorf("start and end date cannot be empty")
// 	}

// 	cacheKey := fmt.Sprintf("attendance:daily:%s:%s-%s", dept, start, end)

// 	// Cek Redis
// 	if val, err := r.rdb.Get(ctx, cacheKey).Result(); err == nil {
// 		var cached []*biz.DailyAttendanceReport
// 		if err := json.Unmarshal([]byte(val), &cached); err == nil {
// 			r.log.Infof("✅ Redis cache hit: %s", cacheKey)
// 			return cached, nil
// 		}
// 		r.log.Warnf("⚠️ Redis unmarshal failed [%s]: %v", cacheKey, err)
// 	} else if err != redis.Nil {
// 		r.log.Errorf("❌ Redis GET error [%s]: %v", cacheKey, err)
// 	}

// 	// Ambil employers
// 	empsResp, err := r.employersClient.GetEmployersFilterDepartCode(ctx, &empv1.GetEmployersFilterDepartCodeRequest{
// 		Departcode: dept,
// 	})
// 	if err != nil {
// 		return nil, fmt.Errorf("failed to get employers: %w", err)
// 	}
// 	if len(empsResp.Result) == 0 {
// 		return []*biz.DailyAttendanceReport{}, nil
// 	}

// 	karyaCodes := extractKaryaCodes(empsResp.Result)
// 	// kodePeru := extractKodePerusahaan(empsResp.Result)
// 	// kodeCab := extractKodeCabang(empsResp.Result)

// 	// if len(kodePeru) == 0 || len(kodeCab) == 0 {
// 	// 	return nil, fmt.Errorf("kode perusahaan atau kode cabang kosong untuk departemen %s", dept)
// 	// }

// 	// // Ambil info perusahaan
// 	// perResp, err := r.orgV1Client.GetPerusahaan(ctx, &orgv1.GetPerusahaanRequest{
// 	// 	KodePerusahaan: kodePeru[0],
// 	// // })
// 	// if err != nil || perResp == nil || perResp.Result == nil {
// 	// 	return nil, fmt.Errorf("gagal ambil data perusahaan: %w", err)
// 	// }

// 	// // Ambil info cabang
// 	// cabangResp, err := r.orgV1Client.GetCabang(ctx, &orgv1.GetCabangRequest{
// 	// 	KodeCabang: kodeCab[0],
// 	// })
// 	// if err != nil || cabangResp == nil || cabangResp.Result == nil {
// 	// 	return nil, fmt.Errorf("gagal ambil data cabang: %w", err)
// 	// }

// 	// Query attendance
// 	type Result struct {
// 		UserID   string
// 		DeviceIP string
// 		Tgl      string
// 		ClockIn  string
// 		ClockOut string
// 	}
// 	var results []Result

// 	startTime := time.Now()
// 	err = r.data.db.
// 		Table("attendance_log").
// 		Select([]string{
// 			"user_id",
// 			"device_ip",
// 			"TO_CHAR(att_log::date, 'YYYY-MM-DD') AS tgl",
// 			"TO_CHAR(MIN(att_log) FILTER (WHERE status = 0), 'HH24:MI') AS clock_in",
// 			"TO_CHAR(MAX(att_log) FILTER (WHERE status = 1), 'HH24:MI') AS clock_out",
// 		}).
// 		Where("user_id IN ?", karyaCodes).
// 		Where("att_log::date BETWEEN ? AND ?", start, end).
// 		Group("user_id, device_ip, att_log::date").
// 		Order("user_id, att_log::date").
// 		Scan(&results).Error
// 	r.log.Infof("🐘 Query executed in %s", time.Since(startTime))
// 	if err != nil {
// 		return nil, fmt.Errorf("gorm query error: %w", err)
// 	}

// 	// Map employer
// 	employerMap := make(map[string]*empv1.EmployerItem)
// 	for _, emp := range empsResp.Result {
// 		employerMap[strings.TrimSpace(emp.KaryaCode)] = emp
// 	}

// 	// Build data attendance
// 	dataMap := make(map[string][]biz.DailyAttendance)
// 	for _, row := range results {
// 		emp := employerMap[strings.TrimSpace(row.UserID)]
// 		if emp == nil {
// 			r.log.Warnf("⚠️ Employer tidak ditemukan untuk user_id %s", row.UserID)
// 			continue
// 		}
// 		tglParsed, err := time.Parse("2006-01-02", row.Tgl)
// 		if err != nil {
// 			r.log.Warnf("⚠️ Invalid date: %s", row.Tgl)
// 			continue
// 		}
// 		dataMap[emp.GetKaryaName()] = append(dataMap[emp.GetKaryaName()], biz.DailyAttendance{
// 			KaryaCode:  row.UserID,
// 			KaryaName:  safeStr(emp.GetKaryaName()),
// 			Department: safeStr(emp.GetDepartment()),
// 			Tgl:        row.Tgl,
// 			Hari:       localizeDayToIndo(tglParsed.Weekday()),
// 			ClockIn:    row.ClockIn,
// 			ClockOut:   row.ClockOut,
// 			DeviceIP:   row.DeviceIP,
// 		})
// 	}

// 	// Build report per employer
// 	var reports []*biz.DailyAttendanceReport
// 	for _, emp := range empsResp.Result {
// 		reports = append(reports, &biz.DailyAttendanceReport{
// 			KodePerusahaan: kodePeru[0],
// 			NamaPerusahaan: safeStr(perResp.Result.GetNamaPerusahaan()),
// 			KodeCabang:     kodeCab[0],
// 			Cabang:         safeStr(cabangResp.Result.GetCabang()),
// 			Nama:           safeStr(emp.GetKaryaName()),
// 			Jabatan:        safeStr(emp.GetDepartment()),
// 			Periode:        fmt.Sprintf("%s - %s", start, end),
// 			DibuatOleh:     "Suroso", // TODO: ambil dari Keycloak
// 			DiperiksaOleh:  "Admin",
// 			DisetujuiOleh:  "Admin",
// 			Data:           dataMap[safeStr(emp.GetKaryaName())],
// 		})
// 	}

// 	// Simpan ke Redis
// 	if len(reports) > 0 {
// 		if bytes, err := json.Marshal(reports); err == nil {
// 			if setErr := r.rdb.Set(ctx, cacheKey, bytes, 3*time.Minute).Err(); setErr != nil {
// 				r.log.Warnf("⚠️ Redis SET error [%s]: %v", cacheKey, setErr)
// 			}
// 		} else {
// 			r.log.Warnf("⚠️ Failed to marshal daily attendance: %v", err)
// 		}
// 	}

// 	return reports, nil
// }

// func extractKaryaCodes(emps []*empv1.EmployerItem) []string {
// 	codes := make([]string, 0, len(emps))
// 	for _, e := range emps {
// 		codes = append(codes, e.KaryaCode)
// 	}
// 	return codes
// }

func findEmployer(karyaCode string, emps []*empv1.EmployerItem) *empv1.EmployerItem {
	for _, e := range emps {
		if e.KaryaCode == karyaCode {
			return e
		}
	}
	return &empv1.EmployerItem{}
}

func getDayName(dateStr string) string {
	t, err := time.Parse("2006-01-02", dateStr)
	if err != nil {
		return ""
	}
	return t.Weekday().String()
}

// func (r *attendanceRawRepo) GetAttendanceReport(
// 	ctx context.Context,
// 	startDate, endDate, depart string,
// ) ([]*biz.DailyAttendanceReport, error) {

// 	cacheKey := fmt.Sprintf("attendance:report:%s:%s-%s", depart, startDate, endDate)

// 	// 	// 1️⃣ Cek Redis Cache
// 	if val, err := r.rdb.Get(ctx, cacheKey).Result(); err == nil {
// 		var cached []*biz.DailyAttendanceReport
// 		if jsonErr := json.Unmarshal([]byte(val), &cached); jsonErr == nil {
// 			r.log.Infof("✅ Redis cache hit: %s", cacheKey)
// 			return cached, nil
// 		}
// 		r.log.Warnf("⚠️ Redis unmarshal failed for key [%s]: %v", cacheKey, err)
// 	} else if err != redis.Nil {
// 		r.log.Errorf("❌ Redis GET error for key [%s]: %v", cacheKey, err)
// 	}

// 	// 2️⃣ Ambil Employers
// 	empsResp, err := r.employersClient.GetEmployersFilterDepartCode(ctx, &empv1.GetEmployersFilterDepartCodeRequest{
// 		Departcode: depart,
// 	})
// 	karyaCodes := extractKaryaCodes(empsResp.Result)
// 	if err != nil {
// 		return nil, fmt.Errorf("failed to get employer: %w", err)
// 	}
// 	if len(empsResp.Result) == 0 {
// 		return []*biz.DailyAttendanceReport{}, nil
// 	}
// 	emp := empsResp.Result[0] // hanya satu karena by ID

// 	// 3️⃣ Ambil Perusahaan (by departcode dari employer)
// 	companyResp, err := r.employersClient.GetPerusahaan(ctx, &empv1.GetPerusahaanRequest{
// 		Departcode: depart,
// 	})
// 	if err != nil {
// 		return nil, fmt.Errorf("failed to get perusahaan: %w", err)
// 	}
// 	if len(companyResp.Perusahaan) == 0 {
// 		return []*biz.DailyAttendanceReport{}, nil
// 	}
// 	comp := companyResp.Perusahaan[0]

// 	departResp, err := r.departmentClient.GetDepartmentCode(ctx, &departmentv1.GetDepartmentCodeRequest{
// 		DepartCode: depart,
// 	})
// 	if err != nil {
// 		return nil, fmt.Errorf("failed to get perusahaan: %w", err)
// 	}
// 	if len(departResp.DepartName) == 0 {
// 		return []*biz.DailyAttendanceReport{}, nil
// 	}
// 	dep := departResp.DepartName[0]

// 	// 4️⃣ Query Attendance dari DB
// 	type Result struct {
// 		Tgl      string
// 		ClockIn  string
// 		ClockOut string
// 		DeviceIp string
// 	}
// 	var results []Result
// 	startTime := time.Now()
// 	err = r.data.db.
// 		Table("attendance_log").
// 		Select([]string{
// 			"user_id",
// 			"device_ip",
// 			"TO_CHAR(att_log::date, 'YYYY-MM-DD') AS tgl",
// 			"TO_CHAR(MIN(att_log) FILTER (WHERE status = 0), 'HH24:MI') AS clock_in",
// 			"TO_CHAR(MAX(att_log) FILTER (WHERE status = 1), 'HH24:MI') AS clock_out",
// 		}).
// 		Where("user_id IN ?", karyaCodes).
// 		Where("att_log::date BETWEEN ? AND ?", startDate, endDate).
// 		Group("user_id, device_ip, att_log::date").
// 		Order("user_id, att_log::date").
// 		Scan(&results).Error
// 	r.log.Infof("🐘 Query executed in %s", time.Since(startTime))
// 	if err != nil {
// 		return nil, fmt.Errorf("gorm query error: %w", err)
// 	}

// 	// 5️⃣ Mapping hasil ke laporan
// 	report := &biz.DailyAttendanceReport{
// 		KodePerusahaan: comp.KodePerusahaan,
// 		NamaPerusahaan: comp.NamaPerusahaan,
// 		KodeCabang:     comp.KodeCabang,
// 		Cabang:         comp.Cabang,
// 		Department:     [],
// 		Nama:           emp.KaryaName,
// 		// Jabatan:        emp.Jabatan,
// 		Periode:       fmt.Sprintf("%s - %s", startDate, endDate),
// 		DibuatOleh:    "Suroso", // TODO: ambil dari Keycloak
// 		DiperiksaOleh: "Heri",
// 		DisetujuiOleh: "Agus",
// 		Data:          []biz.DailyAttendance{},
// 	}

// 	for _, row := range results {
// 		report.Data = append(report.Data, biz.DailyAttendance{
// 			KaryaCode:  emp.KaryaCode,
// 			KaryaName:  emp.KaryaName,
// 			Department: emp.Department,
// 			// Jabatan:    emp.Jabatan,
// 			Tgl:      row.Tgl,
// 			Hari:     getDayName(row.Tgl),
// 			ClockIn:  parseStatus(row.ClockIn),    // contoh: "Clock-In" atau "Terlambat"
// 			ClockOut: parseEvaluasi(row.ClockOut), // contoh: "Sesuai Jadwal"
// 			DeviceIP: row.DeviceIp,                // opsional
// 		})
// 	}

// 	// 6️⃣ Simpan ke Redis
// 	if dataJSON, err := json.Marshal([]*biz.DailyAttendanceReport{report}); err == nil {
// 		_ = r.rdb.Set(ctx, cacheKey, dataJSON, 3*time.Minute).Err()
// 	}

// 	return []*biz.DailyAttendanceReport{report}, nil
// }

// func (r *attendanceRawRepo) GetAttendanceReport(
// 	ctx context.Context,
// 	startDate, endDate, depart string,
// ) ([]*biz.DailyAttendanceReport, error) {

// 	cacheKey := fmt.Sprintf("attendance:report:%s:%s-%s", depart, startDate, endDate)

// 	// 	// 1️⃣ Cek Redis Cache
// 	if val, err := r.rdb.Get(ctx, cacheKey).Result(); err == nil {
// 		var cached []*biz.DailyAttendanceReport
// 		if jsonErr := json.Unmarshal([]byte(val), &cached); jsonErr == nil {
// 			r.log.Infof("✅ Redis cache hit: %s", cacheKey)
// 			return cached, nil
// 		}
// 		r.log.Warnf("⚠️ Redis unmarshal failed for key [%s]: %v", cacheKey, err)
// 	} else if err != redis.Nil {
// 		r.log.Errorf("❌ Redis GET error for key [%s]: %v", cacheKey, err)
// 	}

// 	// 2️⃣ Ambil Employers
// 	empsResp, err := r.employersClient.GetEmployersFilterDepartCode(ctx, &empv1.GetEmployersFilterDepartCodeRequest{
// 		Departcode: depart,
// 	})
// 	if err != nil {
// 		return nil, fmt.Errorf("failed to get employers: %w", err)
// 	}
// 	if len(empsResp.Result) == 0 {
// 		return []*biz.DailyAttendanceReport{}, nil
// 	}
// 	karyaCodes := extractKaryaCodes(empsResp.Result)

// 	// 3️⃣ Ambil Perusahaan (by departcode)
// 	companyResp, err := r.employersClient.GetPerusahaan(ctx, &empv1.GetPerusahaanRequest{
// 		Departcode: depart,
// 	})
// 	if err != nil {
// 		return nil, fmt.Errorf("failed to get perusahaan: %w", err)
// 	}
// 	if len(companyResp.Perusahaan) == 0 {
// 		return []*biz.DailyAttendanceReport{}, nil
// 	}
// 	comp := companyResp.Perusahaan[0]

// 	// 4️⃣ Ambil Department
// 	departResp, err := r.departmentClient.GetDepartmentCode(ctx, &departmentv1.GetDepartmentCodeRequest{
// 		DepartCode: depart,
// 	})
// 	if err != nil {
// 		return nil, fmt.Errorf("failed to get department: %w", err)
// 	}
// 	if len(departResp.DepartName) == 0 {
// 		return []*biz.DailyAttendanceReport{}, nil
// 	}
// 	// depName := departResp.DepartName[0]
// 	depName := string(departResp.DepartName)

// 	// 5️⃣ Query Attendance dari DB
// 	type Result struct {
// 		Tgl      string
// 		ClockIn  string
// 		ClockOut string
// 		DeviceIp string
// 		UserID   string
// 	}
// 	var results []Result

// 	startTime := time.Now()
// 	err = r.data.db.
// 		Table("attendance_log").
// 		Select([]string{
// 			"user_id",
// 			"device_ip",
// 			"TO_CHAR(att_log::date, 'YYYY-MM-DD') AS tgl",
// 			"TO_CHAR(MIN(att_log) FILTER (WHERE status = 0), 'HH24:MI') AS clock_in",
// 			"TO_CHAR(MAX(att_log) FILTER (WHERE status = 1), 'HH24:MI') AS clock_out",
// 		}).
// 		Where("user_id IN ?", karyaCodes).
// 		Where("att_log::date BETWEEN ? AND ?", startDate, endDate).
// 		Group("user_id, device_ip, att_log::date").
// 		Order("user_id, att_log::date").
// 		Scan(&results).Error
// 	r.log.Infof("🐘 Query executed in %s", time.Since(startTime))
// 	if err != nil {
// 		return nil, fmt.Errorf("gorm query error: %w", err)
// 	}

// 	// 6️⃣ Mapping hasil ke laporan
// 	report := &biz.DailyAttendanceReport{
// 		KodePerusahaan: comp.KodePerusahaan,
// 		NamaPerusahaan: comp.NamaPerusahaan,
// 		KodeCabang:     comp.KodeCabang,
// 		Cabang:         comp.Cabang,
// 		Department:     depName,
// 		Periode:        fmt.Sprintf("%s - %s", startDate, endDate),
// 		DibuatOleh:     "Suroso", // TODO: ambil dari Keycloak
// 		DiperiksaOleh:  "Heri",
// 		DisetujuiOleh:  "Agus",
// 		Data:           []biz.DailyAttendance{},
// 	}

// 	// Map result ke employer terkait
// 	empMap := make(map[string]*empv1.EmployerItem)
// 	for _, e := range empsResp.Result {
// 		empMap[e.KaryaCode] = e
// 	}

// 	for _, row := range results {
// 		emp := empMap[row.UserID]
// 		if emp == nil {
// 			continue
// 		}
// 		report.Data = append(report.Data, biz.DailyAttendance{
// 			KaryaCode: emp.KaryaCode,
// 			KaryaName: emp.KaryaName,
// 			Tanggal:   row.Tgl,
// 			Hari:      getDayName(row.Tgl),
// 			Status:    parseStatus(row.status),
// 			ClockOut:  parseEvaluasi(row.ClockOut),
// 			DeviceIP:  row.DeviceIp,
// 		})
// 	}

// 	// 7️⃣ Simpan ke Redis
// 	if dataJSON, err := json.Marshal([]*biz.DailyAttendanceReport{report}); err == nil {
// 		if setErr := r.rdb.Set(ctx, cacheKey, dataJSON, 3*time.Minute).Err(); setErr != nil {
// 			r.log.Warnf("⚠️ Failed to set Redis key [%s]: %v", cacheKey, setErr)
// 		}
// 	}

//		return []*biz.DailyAttendanceReport{report}, nil
//	}

// func (r *attendanceRawRepo) GetAttendanceReport(
// 	ctx context.Context,
// 	startDate, endDate, depart string,
// ) ([]*biz.DailyAttendanceReport, error) {

// 	cacheKey := fmt.Sprintf("attendance:report:%s:%s-%s", depart, startDate, endDate)

// 	// 1️⃣ Cek Redis Cache
// 	if val, err := r.rdb.Get(ctx, cacheKey).Result(); err == nil {
// 		var cached []*biz.DailyAttendanceReport
// 		if jsonErr := json.Unmarshal([]byte(val), &cached); jsonErr == nil {
// 			r.log.Infof("✅ Redis cache hit: %s", cacheKey)
// 			return cached, nil
// 		}
// 		r.log.Warnf("⚠️ Redis unmarshal failed for key [%s]: %v", cacheKey, err)
// 	} else if err != redis.Nil {
// 		r.log.Errorf("❌ Redis GET error for key [%s]: %v", cacheKey, err)
// 	}

// 	// 2️⃣ Ambil Employers
// 	empsResp, err := r.employersClient.GetEmployersFilterDepartCode(ctx, &empv1.GetEmployersFilterDepartCodeRequest{
// 		Departcode: depart,
// 	})
// 	if err != nil {
// 		return nil, fmt.Errorf("failed to get employers: %w", err)
// 	}
// 	if len(empsResp.Result) == 0 {
// 		return []*biz.DailyAttendanceReport{}, nil
// 	}
// 	karyaCodes := extractKaryaCodes(empsResp.Result)

// 	// 3️⃣ Ambil Perusahaan
// 	companyResp, err := r.employersClient.GetPerusahaan(ctx, &empv1.GetPerusahaanRequest{
// 		Departcode: depart,
// 	})
// 	if err != nil {
// 		return nil, fmt.Errorf("failed to get perusahaan: %w", err)
// 	}
// 	if len(companyResp.Perusahaan) == 0 {
// 		return []*biz.DailyAttendanceReport{}, nil
// 	}
// 	comp := companyResp.Perusahaan[0]

// 	// 4️⃣ Ambil Department
// 	departResp, err := r.departmentClient.GetDepartmentCode(ctx, &departmentv1.GetDepartmentCodeRequest{
// 		DepartCode: depart,
// 	})
// 	if err != nil {
// 		return nil, fmt.Errorf("failed to get department: %w", err)
// 	}
// 	if departResp.DepartName == "" {
// 		return []*biz.DailyAttendanceReport{}, nil
// 	}
// 	depName := departResp.DepartName

// 	// 5️⃣ Query Attendance dari DB
// 	type Result struct {
// 		Tgl      string
// 		Jam      string
// 		ClockIn  string
// 		ClockOut string
// 		DeviceIp string
// 		UserID   string
// 	}
// 	var results []Result

// 	startTime := time.Now()
// 	err = r.data.db.
// 		Table("attendance_log").
// 		Select([]string{
// 			"user_id",
// 			"device_ip",
// 			"att_log AS jam",
// 			"TO_CHAR(att_log::date, 'YYYY-MM-DD') AS tgl",
// 			"TO_CHAR(MIN(att_log) FILTER (WHERE status = 0), 'HH24:MI') AS clock_in",
// 			"TO_CHAR(MAX(att_log) FILTER (WHERE status = 1), 'HH24:MI') AS clock_out",
// 		}).
// 		Where("user_id IN ?", karyaCodes).
// 		Where("att_log::date BETWEEN ? AND ?", startDate, endDate).
// 		Group("user_id, device_ip, att_log::date, att_log").
// 		Order("user_id, att_log::date").
// 		Scan(&results).Error
// 	r.log.Infof("🐘 Query executed in %s", time.Since(startTime))
// 	if err != nil {
// 		return nil, fmt.Errorf("gorm query error: %w", err)
// 	}

// 	// 6️⃣ Mapping hasil ke laporan
// 	report := &biz.DailyAttendanceReport{
// 		KodePerusahaan: comp.KodePerusahaan,
// 		NamaPerusahaan: comp.NamaPerusahaan,
// 		KodeCabang:     comp.KodeCabang,
// 		Cabang:         comp.Cabang,
// 		Department:     depName,
// 		Periode:        fmt.Sprintf("%s - %s", startDate, endDate),
// 		DibuatOleh:     "Suroso",
// 		DiperiksaOleh:  "Heri",
// 		DisetujuiOleh:  "Agus",
// 		Data:           []biz.DailyAttendance{},
// 	}

// 	// Map employer untuk akses cepat
// 	empMap := make(map[string]*empv1.EmployerItem)
// 	for _, e := range empsResp.Result {
// 		empMap[e.KaryaCode] = e
// 	}

// 	for _, row := range results {
// 		emp, exists := empMap[row.UserID]
// 		if !exists {
// 			continue
// 		}

// 		report.Data = append(report.Data, biz.DailyAttendance{
// 			KaryaCode: emp.KaryaCode,
// 			KaryaName: emp.KaryaName,
// 			Tanggal:   row.Tgl,
// 			Jam:       row.Jam,
// 			Status: []biz.AttStatus{
// 				{ClockIn: row.ClockIn, ClockOut: row.ClockOut},
// 			},
// 			Evaluasi: parseEvaluasi(row.ClockOut),
// 		})
// 	}

// 	// 7️⃣ Simpan ke Redis
// 	if dataJSON, err := json.Marshal([]*biz.DailyAttendanceReport{report}); err == nil {
// 		if setErr := r.rdb.Set(ctx, cacheKey, dataJSON, 3*time.Minute).Err(); setErr != nil {
// 			r.log.Warnf("⚠️ Failed to set Redis key [%s]: %v", cacheKey, setErr)
// 		}
// 	}
// 	r.log.Infof("📄 Report generated: %+v", report)

// 	return []*biz.DailyAttendanceReport{report}, nil
// }

func (r *attendanceRawRepo) GetAttendanceReport(
	ctx context.Context,
	startDate, endDate, depart string,
) ([]*biz.DailyAttendanceReport, error) {

	cacheKey := fmt.Sprintf("attendance:report:%s:%s-%s", depart, startDate, endDate)

	// 1️⃣ Cek Redis Cache
	if val, err := r.rdb.Get(ctx, cacheKey).Result(); err == nil {
		var cached []*biz.DailyAttendanceReport
		if jsonErr := json.Unmarshal([]byte(val), &cached); jsonErr == nil {
			r.log.Infof("✅ Redis cache hit: %s", cacheKey)
			return cached, nil
		}
		r.log.Warnf("⚠️ Redis unmarshal failed for key [%s]: %v", cacheKey, err)
	} else if err != redis.Nil {
		r.log.Errorf("❌ Redis GET error for key [%s]: %v", cacheKey, err)
	}

	// 2️⃣ Ambil Employers
	empsResp, err := r.employersClient.GetEmployersFilterDepartCode(ctx, &empv1.GetEmployersFilterDepartCodeRequest{
		Departcode: depart,
	})
	if err != nil {
		return nil, fmt.Errorf("failed to get employers: %w", err)
	}
	if len(empsResp.Result) == 0 {
		return []*biz.DailyAttendanceReport{}, nil
	}
	karyaCodes := extractKaryaCodes(empsResp.Result)

	// 3️⃣ Ambil Perusahaan
	companyResp, err := r.employersClient.GetPerusahaan(ctx, &empv1.GetPerusahaanRequest{
		Departcode: depart,
	})
	if err != nil {
		return nil, fmt.Errorf("failed to get perusahaan: %w", err)
	}
	if len(companyResp.Perusahaan) == 0 {
		return []*biz.DailyAttendanceReport{}, nil
	}
	comp := companyResp.Perusahaan[0]

	// 4️⃣ Ambil Department
	departResp, err := r.departmentClient.GetDepartmentCode(ctx, &departmentv1.GetDepartmentCodeRequest{
		DepartCode: depart,
	})
	if err != nil {
		return nil, fmt.Errorf("failed to get department: %w", err)
	}
	if departResp.DepartName == "" {
		return []*biz.DailyAttendanceReport{}, nil
	}
	depName := departResp.DepartName

	// 5️⃣ Query Attendance dari DB
	type Result struct {
		Tgl      string
		Jam      string
		ClockIn  string
		ClockOut string
		UserID   string
	}

	var results []Result
	startTime := time.Now()

	err = r.data.db.
		Table("attendance_log").
		Select([]string{
			"user_id",
			"device_ip",
			"att_log AS jam",
			"TO_CHAR(att_log::date, 'YYYY-MM-DD') AS tgl",
			"TO_CHAR(MIN(att_log) FILTER (WHERE status = 0), 'HH24:MI') AS clock_in",
			"TO_CHAR(MAX(att_log) FILTER (WHERE status = 1), 'HH24:MI') AS clock_out",
		}).
		Where("user_id IN ?", karyaCodes).
		Where("att_log::date BETWEEN ? AND ?", startDate, endDate).
		Group("user_id, device_ip, att_log::date").
		Order("user_id, att_log::date").
		Scan(&results).Error
	r.log.Infof("🐘 Query executed in %s", time.Since(startTime))

	if err != nil {
		return nil, fmt.Errorf("gorm query error: %w", err)
	}

	// 6️⃣ Mapping hasil ke laporan
	report := &biz.DailyAttendanceReport{
		KodePerusahaan: comp.KodePerusahaan,
		NamaPerusahaan: comp.NamaPerusahaan,
		KodeCabang:     comp.KodeCabang,
		Cabang:         comp.Cabang,
		Department:     depName,
		Periode:        fmt.Sprintf("%s - %s", startDate, endDate),
		DibuatOleh:     "Suroso",
		DiperiksaOleh:  "Heri",
		DisetujuiOleh:  "Agus",
		Data:           make([]biz.DailyAttendance, 0, len(results)),
	}

	// Map employer untuk akses cepat
	empMap := make(map[string]*empv1.EmployerItem)
	for _, e := range empsResp.Result {
		empMap[e.KaryaCode] = e
	}

	for _, row := range results {
		if emp, exists := empMap[row.UserID]; exists {
			report.Data = append(report.Data, biz.DailyAttendance{
				KaryaCode: emp.KaryaCode,
				KaryaName: emp.KaryaName,
				Tanggal:   row.Tgl,
				Jam:       row.Jam,
				Status: []*biz.AttStatus{
					{ClockIn: row.ClockIn, ClockOut: row.ClockOut},
				},
				Evaluasi: parseEvaluasi(row.ClockOut),
			})
		}
	}

	r.log.Infof("📄 Report generated with %d records", len(report.Data))

	// 7️⃣ Simpan ke Redis
	if dataJSON, err := json.Marshal([]*biz.DailyAttendanceReport{report}); err == nil {
		if setErr := r.rdb.Set(ctx, cacheKey, dataJSON, 3*time.Minute).Err(); setErr != nil {
			r.log.Warnf("⚠️ Failed to set Redis key [%s]: %v", cacheKey, setErr)
		}
	}

	return []*biz.DailyAttendanceReport{report}, nil
}

// parseEvaluasi ubah jam menjadi evaluasi
func parseEvaluasi(clockOut string) string {
	if clockOut == "" {
		return "Tidak Pulang"
	}
	return "Sesuai Jadwal"
}

// func (r *attendanceRawRepo) GetAttendanceReport(
// 	ctx context.Context,
// 	startDate, endDate, depart string,
// ) ([]*biz.DailyAttendanceReport, error) {

// 	cacheKey := fmt.Sprintf("attendance:report:%s:%s-%s", depart, startDate, endDate)

// 	// 1️⃣ Cek Redis Cache
// 	if val, err := r.rdb.Get(ctx, cacheKey).Result(); err == nil {
// 		var cached []*biz.DailyAttendanceReport
// 		if jsonErr := json.Unmarshal([]byte(val), &cached); jsonErr == nil {
// 			r.log.Infof("✅ Redis cache hit: %s", cacheKey)
// 			return cached, nil
// 		}
// 		r.log.Warnf("⚠️ Redis unmarshal failed for key [%s]: %v", cacheKey, err)
// 	} else if err != redis.Nil {
// 		r.log.Errorf("❌ Redis GET error for key [%s]: %v", cacheKey, err)
// 	}

// 	// 2️⃣ Ambil Employers
// 	empsResp, err := r.employersClient.GetEmployersFilterDepartCode(ctx, &empv1.GetEmployersFilterDepartCodeRequest{
// 		Departcode: depart,
// 	})
// 	if err != nil {
// 		return nil, fmt.Errorf("failed to get employers: %w", err)
// 	}
// 	if len(empsResp.Result) == 0 {
// 		return []*biz.DailyAttendanceReport{}, nil
// 	}
// 	karyaCodes := extractKaryaCodes(empsResp.Result)

// 	// 3️⃣ Ambil Perusahaan
// 	companyResp, err := r.employersClient.GetPerusahaan(ctx, &empv1.GetPerusahaanRequest{
// 		Departcode: depart,
// 	})
// 	if err != nil {
// 		return nil, fmt.Errorf("failed to get perusahaan: %w", err)
// 	}
// 	if len(companyResp.Perusahaan) == 0 {
// 		return []*biz.DailyAttendanceReport{}, nil
// 	}
// 	comp := companyResp.Perusahaan[0]

// 	// 4️⃣ Ambil Department
// 	departResp, err := r.departmentClient.GetDepartmentCode(ctx, &departmentv1.GetDepartmentCodeRequest{
// 		DepartCode: depart,
// 	})
// 	if err != nil {
// 		return nil, fmt.Errorf("failed to get department: %w", err)
// 	}
// 	if departResp.DepartName == "" {
// 		return []*biz.DailyAttendanceReport{}, nil
// 	}
// 	depName := departResp.DepartName

// 	// 5️⃣ Query Attendance dari DB
// 	type Result struct {
// 		Tgl      string
// 		Jam      string
// 		ClockIn  string
// 		ClockOut string
// 		UserID   string
// 	}

// 	var results []Result
// 	startTime := time.Now()

// 	err = r.data.db.
// 		Table("attendance_log").
// 		Select([]string{
// 			"user_id",
// 			"att_log AS jam",
// 			"TO_CHAR(att_log::date, 'YYYY-MM-DD') AS tgl",
// 			"TO_CHAR(MIN(att_log) FILTER (WHERE status = 0), 'HH24:MI') AS clock_in",
// 			"TO_CHAR(MAX(att_log) FILTER (WHERE status = 1), 'HH24:MI') AS clock_out",
// 		}).
// 		Where("user_id IN ?", karyaCodes).
// 		Where("att_log::date BETWEEN ? AND ?", startDate, endDate).
// 		Group("user_id, att_log::date, att_log").
// 		Order("user_id, att_log::date").
// 		Scan(&results).Error

// 	r.log.Infof("🐘 Query executed in %s", time.Since(startTime))
// 	if err != nil {
// 		return nil, fmt.Errorf("gorm query error: %w", err)
// 	}

// 	// 6️⃣ Mapping hasil ke laporan
// 	report := &biz.DailyAttendanceReport{
// 		KodePerusahaan: comp.KodePerusahaan,
// 		NamaPerusahaan: comp.NamaPerusahaan,
// 		KodeCabang:     comp.KodeCabang,
// 		Cabang:         comp.Cabang,
// 		Department:     depName,
// 		Periode:        fmt.Sprintf("%s - %s", startDate, endDate),
// 		DibuatOleh:     "Suroso",
// 		DiperiksaOleh:  "Heri",
// 		DisetujuiOleh:  "Agus",
// 		Data:           make([]biz.DailyAttendance, 0, len(results)),
// 	}
// 	r.log.Infof("📄 Report generated with %d records", report)
// 	// Map employer untuk akses cepat
// 	empMap := make(map[string]*empv1.EmployerItem)
// 	for _, e := range empsResp.Result {
// 		empMap[e.KaryaCode] = e
// 	}

// 	for _, row := range results {
// 		if emp, exists := empMap[row.UserID]; exists {
// 			report.Data = append(report.Data, biz.DailyAttendance{
// 				KaryaCode: emp.KaryaCode,
// 				KaryaName: emp.KaryaName,
// 				Tanggal:   row.Tgl,
// 				Jam:       row.Jam,
// 				Status: []*biz.AttStatus{
// 					{ClockIn: row.ClockIn, ClockOut: row.ClockOut},
// 				},
// 				Evaluasi: parseEvaluasi(row.ClockOut),
// 			})
// 		}
// 	}
// 	r.log.Infof("📄 Report generated with %s records", (report))
// 	// 7️⃣ Simpan ke Redis
// 	if dataJSON, err := json.Marshal([]*biz.DailyAttendanceReport{report}); err == nil {
// 		if setErr := r.rdb.Set(ctx, cacheKey, dataJSON, 3*time.Minute).Err(); setErr != nil {
// 			r.log.Warnf("⚠️ Failed to set Redis key [%s]: %v", cacheKey, setErr)
// 		}
// 	}

// 	r.log.Infof("📄 Report generated with %d records", len(report.Data))
// 	return []*biz.DailyAttendanceReport{report}, nil
// }

// func (r *attendanceRawRepo) GetAttendanceReport(
// 	ctx context.Context,
// 	startDate, endDate, depart string,
// ) ([]*biz.DailyAttendanceReport, error) {

// 	cacheKey := fmt.Sprintf("attendance:report:%s:%s-%s", depart, startDate, endDate)

// 	// 1️⃣ Cek Redis Cache
// 	if val, err := r.rdb.Get(ctx, cacheKey).Result(); err == nil {
// 		var cached []*biz.DailyAttendanceReport
// 		if jsonErr := json.Unmarshal([]byte(val), &cached); jsonErr == nil {
// 			r.log.Infof("✅ Redis cache hit: %s", cacheKey)
// 			return cached, nil
// 		}
// 		r.log.Warnf("⚠️ Redis unmarshal failed for key [%s]: %v", cacheKey, err)
// 	} else if err != redis.Nil {
// 		r.log.Errorf("❌ Redis GET error for key [%s]: %v", cacheKey, err)
// 	}
// 	// 2️⃣ Ambil Employers
// 	empsResp, err := r.employersClient.GetEmployersFilterDepartCode(ctx, &empv1.GetEmployersFilterDepartCodeRequest{
// 		Departcode: depart,
// 	})
// 	if err != nil {
// 		return nil, fmt.Errorf("failed to get employers: %w", err)
// 	}
// 	if len(empsResp.Result) == 0 {
// 		return []*biz.DailyAttendanceReport{}, nil
// 	}
// 	karyaCodes := extractKaryaCodes(empsResp.Result)

// 	// 3️⃣ Ambil Perusahaan
// 	companyResp, err := r.employersClient.GetPerusahaan(ctx, &empv1.GetPerusahaanRequest{
// 		Departcode: depart,
// 	})
// 	if err != nil {
// 		return nil, fmt.Errorf("failed to get perusahaan: %w", err)
// 	}
// 	if len(companyResp.Perusahaan) == 0 {
// 		return []*biz.DailyAttendanceReport{}, nil
// 	}
// 	comp := companyResp.Perusahaan[0]

// 	// 4️⃣ Ambil Department
// 	departResp, err := r.departmentClient.GetDepartmentCode(ctx, &departmentv1.GetDepartmentCodeRequest{
// 		DepartCode: depart,
// 	})
// 	if err != nil {
// 		return nil, fmt.Errorf("failed to get department: %w", err)
// 	}
// 	if len(departResp.DepartName) == 0 {
// 		return []*biz.DailyAttendanceReport{}, nil
// 	}
// 	depName := string(departResp.DepartName)

// 	// 5️⃣ Query Attendance dari DB
// 	type Result struct {
// 		Tgl      string
// 		Jam      string
// 		ClockIn  string
// 		ClockOut string
// 		DeviceIp string
// 		UserID   string
// 	}
// 	var results []Result

// 	startTime := time.Now()
// 	err = r.data.db.
// 		Table("attendance_log").
// 		Select([]string{
// 			"user_id",
// 			"device_ip",
// 			"att_log AS jam",
// 			"TO_CHAR(att_log::date, 'YYYY-MM-DD') AS tgl",
// 			"TO_CHAR(MIN(att_log) FILTER (WHERE status = 0), 'HH24:MI') AS clock_in",
// 			"TO_CHAR(MAX(att_log) FILTER (WHERE status = 1), 'HH24:MI') AS clock_out",
// 		}).
// 		Where("user_id IN ?", karyaCodes).
// 		Where("att_log::date BETWEEN ? AND ?", startDate, endDate).
// 		Group("user_id, device_ip, att_log::date").
// 		Order("user_id, att_log::date").
// 		Scan(&results).Error
// 	r.log.Infof("🐘 Query executed in %s", time.Since(startTime))
// 	if err != nil {
// 		return nil, fmt.Errorf("gorm query error: %w", err)
// 	}

// 	// 6️⃣ Mapping hasil ke laporan
// 	report := &biz.DailyAttendanceReport{
// 		KodePerusahaan: comp.KodePerusahaan,
// 		NamaPerusahaan: comp.NamaPerusahaan,
// 		KodeCabang:     comp.KodeCabang,
// 		Cabang:         comp.Cabang,
// 		Department:     depName,
// 		Periode:        fmt.Sprintf("%s - %s", startDate, endDate),
// 		DibuatOleh:     "Suroso",
// 		DiperiksaOleh:  "Heri",
// 		DisetujuiOleh:  "Agus",
// 		Data:           []biz.DailyAttendance{},
// 	}

// 	// Map employer untuk akses cepat
// 	empMap := make(map[string]*empv1.EmployerItem)
// 	for _, e := range empsResp.Result {
// 		empMap[e.KaryaCode] = e
// 	}

// 	for _, row := range results {
// 		emp := empMap[row.UserID]
// 		if emp == nil {
// 			continue
// 		}
// 		report.Data = append(report.Data, biz.DailyAttendance{
// 			KaryaCode: emp.KaryaCode,
// 			KaryaName: emp.KaryaName,
// 			Tanggal:   row.Tgl,
// 			Jam:       row.Jam,
// 			Status:    parseStatus(row.ClockIn),
// 			Evaluasi:  parseEvaluasi(row.ClockOut),
// 		})
// 	}

// 	// 7️⃣ Simpan ke Redis
// 	if dataJSON, err := json.Marshal([]*biz.DailyAttendanceReport{report}); err == nil {
// 		if setErr := r.rdb.Set(ctx, cacheKey, dataJSON, 3*time.Minute).Err(); setErr != nil {
// 			r.log.Warnf("⚠️ Failed to set Redis key [%s]: %v", cacheKey, setErr)
// 		}
// 	}
// 	r.log.Info("INI REPORT :", report)

// 	return []*biz.DailyAttendanceReport{report}, nil
// }

// // parseStatus ubah jam menjadi status
// func parseStatus(clockIn string) string {
// 	if clockIn == "" {
// 		return "Tidak Hadir"
// 	}
// 	// logika tambahan jika mau tandai terlambat
// 	return "Clock-In"
// }

// // parseEvaluasi ubah jam menjadi evaluasi
// func parseEvaluasi(clockOut string) string {
// 	if clockOut == "" {
// 		return "Tidak Pulang"
// 	}
// 	return "Sesuai Jadwal"
// }

// func (r *attendanceRawRepo) GetAttendanceReport(
// 	ctx context.Context,
// 	startDate, endDate, depart string,
// ) ([]*biz.DailyAttendanceReport, error) {

// 	cacheKey := fmt.Sprintf("attendance:report:%s:%s-%s", depart, startDate, endDate)

// 	// 1️⃣ Cek Redis Cache
// 	if val, err := r.rdb.Get(ctx, cacheKey).Result(); err == nil {
// 		var cached []*biz.DailyAttendanceReport
// 		if jsonErr := json.Unmarshal([]byte(val), &cached); jsonErr == nil {
// 			r.log.Infof("✅ Redis cache hit: %s", cacheKey)
// 			return cached, nil
// 		}
// 		r.log.Warnf("⚠️ Redis unmarshal failed for key [%s]: %v", cacheKey, err)
// 	} else if err != redis.Nil {
// 		r.log.Errorf("❌ Redis GET error for key [%s]: %v", cacheKey, err)
// 	}

// 	// 2️⃣ Ambil Employers
// 	empsResp, err := r.employersClient.GetEmployersFilterDepartCode(ctx, &empv1.GetEmployersFilterDepartCodeRequest{
// 		Departcode: depart,
// 	})
// 	if err != nil {
// 		return nil, fmt.Errorf("failed to get employers: %w", err)
// 	}
// 	if len(empsResp.Result) == 0 {
// 		return []*biz.DailyAttendanceReport{}, nil
// 	}
// 	karyaCodes := extractKaryaCodes(empsResp.Result)
// 	if len(karyaCodes) == 0 {
// 		return []*biz.DailyAttendanceReport{}, nil
// 	}

// 	// 3️⃣ Ambil Perusahaan
// 	companyResp, err := r.employersClient.GetPerusahaan(ctx, &empv1.GetPerusahaanRequest{
// 		Departcode: depart,
// 	})
// 	if err != nil {
// 		return nil, fmt.Errorf("failed to get perusahaan: %w", err)
// 	}
// 	if len(companyResp.Perusahaan) == 0 {
// 		return []*biz.DailyAttendanceReport{}, nil
// 	}

// 	// Map berdasarkan UserID / KaryaCode dari employers
// 	companyMap := make(map[string]biz.PerusahaanData)
// 	for _, emp := range empsResp.Result {
// 		for _, c := range companyResp.Perusahaan {
// 			if emp.KaryaCode == c.KaryaCode {
// 				companyMap[emp.KaryaCode] = biz.PerusahaanData{
// 					KodePerusahaan: c.KodePerusahaan,
// 					NamaPerusahaan: c.NamaPerusahaan,
// 					KodeCabang:     c.KodeCabang,
// 					Cabang:         c.Cabang,
// 				}
// 			}
// 		}
// 	}

// 	// 4️⃣ Query Attendance dari DB
// 	type Result struct {
// 		UserID   string
// 		DeviceIP string
// 		Tgl      string
// 		ClockIn  string
// 		ClockOut string
// 	}
// 	var results []Result
// 	startTime := time.Now()
// 	err = r.data.db.
// 		Table("attendance_log").
// 		Select([]string{
// 			"user_id",
// 			"device_ip",
// 			"TO_CHAR(att_log::date, 'YYYY-MM-DD') AS tgl",
// 			"TO_CHAR(MIN(att_log) FILTER (WHERE status = 0), 'HH24:MI') AS clock_in",
// 			"TO_CHAR(MAX(att_log) FILTER (WHERE status = 1), 'HH24:MI') AS clock_out",
// 		}).
// 		Where("user_id IN ?", karyaCodes).
// 		Where("att_log::date BETWEEN ? AND ?", startDate, endDate).
// 		Group("user_id, device_ip, att_log::date").
// 		Order("user_id, att_log::date").
// 		Scan(&results).Error
// 	r.log.Infof("🐘 Query executed in %s", time.Since(startTime))
// 	if err != nil {
// 		return nil, fmt.Errorf("gorm query error: %w", err)
// 	}

// 	// 5️⃣ Mapping hasil ke laporan per karyawan
// 	reportMap := make(map[string]*biz.DailyAttendanceReport)

// 	for _, row := range results {
// 		emp := findEmployer(row.UserID, empsResp.Result)
// 		comp := companyMap[row.UserID]

// 		if _, exists := reportMap[row.UserID]; !exists {
// 			reportMap[row.UserID] = &biz.DailyAttendanceReport{
// 				KodePerusahaan: comp.KodePerusahaan,
// 				NamaPerusahaan: comp.NamaPerusahaan,
// 				KodeCabang:     comp.KodeCabang,
// 				Cabang:         comp.Cabang,
// 				Nama:           emp.KaryaName,
// 				// Jabatan:        emp.Jabatan,
// 				Periode:       fmt.Sprintf("%s - %s", startDate, endDate),
// 				DibuatOleh:    "Suroso", // TODO: dari Keycloak
// 				DiperiksaOleh: "aaa",
// 				DisetujuiOleh: "aaa",
// 				Data:          []biz.DailyAttendance{},
// 			}
// 		}

// 		reportMap[row.UserID].Data = append(reportMap[row.UserID].Data, biz.DailyAttendance{
// 			KaryaCode:  row.UserID,
// 			KaryaName:  emp.KaryaName,
// 			Department: emp.Department,
// 			// Jabatan:    emp.Jabatan,
// 			Tgl:      row.Tgl,
// 			Hari:     getDayName(row.Tgl),
// 			ClockIn:  row.ClockIn,
// 			ClockOut: row.ClockOut,
// 			DeviceIP: row.DeviceIP,
// 		})
// 	}

// 	// 6️⃣ Convert map ke slice
// 	reports := make([]*biz.DailyAttendanceReport, 0, len(reportMap))
// 	for _, rep := range reportMap {
// 		reports = append(reports, rep)
// 	}

// 	// 7️⃣ Simpan ke Redis
// 	if dataJSON, err := json.Marshal(reports); err == nil {
// 		_ = r.rdb.Set(ctx, cacheKey, dataJSON, 10*time.Minute).Err()
// 	}

// 	return reports, nil
// }

// func (r *attendanceRawRepo) GetAttendanceReport(
// 	ctx context.Context,
// 	startDate, endDate, depart string,
// ) ([]*biz.DailyAttendanceReport, error) {

// 	cacheKey := fmt.Sprintf("attendance:report:%s:%s-%s", depart, startDate, endDate)

// 	// 1️⃣ Cek Redis Cache
// 	if val, err := r.rdb.Get(ctx, cacheKey).Result(); err == nil {
// 		var cached []*biz.DailyAttendanceReport
// 		jsonErr := json.Unmarshal([]byte(val), &cached)
// 		if jsonErr := json.Unmarshal([]byte(val), &cached); jsonErr == nil {
// 			r.log.Infof("✅ Redis cache hit: %s", cacheKey)
// 			return cached, nil
// 		}
// 		r.log.Warnf("⚠️ Redis unmarshal failed for key [%s]: %v", cacheKey, jsonErr)
// 	} else if err != redis.Nil {
// 		r.log.Errorf("❌ Redis GET error for key [%s]: %v", cacheKey, err)
// 	}

// 	// 2️⃣ Ambil Employers
// 	empsResp, err := r.employersClient.GetEmployersFilterDepartCode(ctx, &empv1.GetEmployersFilterDepartCodeRequest{
// 		Departcode: depart,
// 	})
// 	if err != nil {
// 		return nil, fmt.Errorf("failed to get employers: %w", err)
// 	}
// 	if len(empsResp.Result) == 0 {
// 		return []*biz.DailyAttendanceReport{}, nil
// 	}
// 	karyaCodes := extractKaryaCodes(empsResp.Result)
// 	if len(karyaCodes) == 0 {
// 		return []*biz.DailyAttendanceReport{}, nil
// 	}

// 	// 3️⃣ Ambil Perusahaan
// 	companyResp, err := r.employersClient.GetPerusahaan(ctx, &empv1.GetPerusahaanRequest{
// 		Departcode: depart,
// 	})
// 	if err != nil {
// 		return nil, fmt.Errorf("failed to get perusahaan: %w", err)
// 	}
// 	if len(companyResp.Perusahaan) == 0 {
// 		return []*biz.DailyAttendanceReport{}, nil
// 	}

// 	// Map KaryaCode -> PerusahaanData
// 	companyMap := make(map[string]biz.PerusahaanData)
// 	for _, c := range companyResp.Perusahaan {
// 		companyMap[c.KaryaCode] = biz.PerusahaanData{
// 			KodePerusahaan: c.KodePerusahaan,
// 			NamaPerusahaan: c.NamaPerusahaan,
// 			KodeCabang:     c.KodeCabang,
// 			Cabang:         c.Cabang,
// 		}
// 	}

// 	// 4️⃣ Query Attendance dari DB
// 	type Result struct {
// 		UserID   string
// 		DeviceIP string
// 		Tgl      string
// 		ClockIn  string
// 		ClockOut string
// 	}
// 	var results []Result
// 	startTime := time.Now()
// 	err = r.data.db.
// 		Table("attendance_log").
// 		Select([]string{
// 			"user_id",
// 			"device_ip",
// 			"TO_CHAR(att_log::date, 'YYYY-MM-DD') AS tgl",
// 			"TO_CHAR(MIN(att_log) FILTER (WHERE status = 0), 'HH24:MI') AS clock_in",
// 			"TO_CHAR(MAX(att_log) FILTER (WHERE status = 1), 'HH24:MI') AS clock_out",
// 		}).
// 		Where("user_id IN ?", karyaCodes).
// 		Where("att_log::date BETWEEN ? AND ?", startDate, endDate).
// 		Group("user_id, device_ip, att_log::date").
// 		Order("user_id, att_log::date").
// 		Scan(&results).Error
// 	r.log.Infof("🐘 Query executed in %s", time.Since(startTime))
// 	if err != nil {
// 		return nil, fmt.Errorf("gorm query error: %w", err)
// 	}

// 	// 5️⃣ Mapping hasil ke laporan per karyawan
// 	reportMap := make(map[string]*biz.DailyAttendanceReport)

// 	for _, row := range results {
// 		emp := findEmployer(row.UserID, empsResp.Result)
// 		comp := companyMap[row.UserID]

// 		if _, exists := reportMap[row.UserID]; !exists {
// 			reportMap[row.UserID] = &biz.DailyAttendanceReport{
// 				KodePerusahaan: comp.KodePerusahaan,
// 				NamaPerusahaan: comp.NamaPerusahaan,
// 				KodeCabang:     comp.KodeCabang,
// 				Cabang:         comp.Cabang,
// 				Nama:           emp.KaryaName,
// 				// Jabatan:        emp.Jabatan,
// 				Periode:       fmt.Sprintf("%s - %s", startDate, endDate),
// 				DibuatOleh:    "Suroso", // TODO: dari Keycloak
// 				DiperiksaOleh: "",
// 				DisetujuiOleh: "",
// 				Data:          []biz.DailyAttendance{},
// 			}
// 		}

// 		reportMap[row.UserID].Data = append(reportMap[row.UserID].Data, biz.DailyAttendance{
// 			KaryaCode:  row.UserID,
// 			KaryaName:  emp.KaryaName,
// 			Department: emp.Department,
// 			Tgl:        row.Tgl,
// 			Hari:       getDayName(row.Tgl),
// 			ClockIn:    row.ClockIn,
// 			ClockOut:   row.ClockOut,
// 			DeviceIP:   row.DeviceIP,
// 		})
// 	}

// 	// 6️⃣ Convert map ke slice
// 	reports := make([]*biz.DailyAttendanceReport, 0, len(reportMap))
// 	for _, rep := range reportMap {
// 		reports = append(reports, rep)
// 	}

// 	// 7️⃣ Simpan ke Redis
// 	if dataJSON, err := json.Marshal(reports); err == nil {
// 		_ = r.rdb.Set(ctx, cacheKey, dataJSON, 10*time.Minute).Err()
// 	}

// 	return reports, nil
// }

// func (r *attendanceRawRepo) GetAttendanceReport(ctx context.Context, start_date, end_date, depart string) ([]*biz.DailyAttendanceReport, error) {
// 	cacheKey := fmt.Sprintf("attendance:report:%s:%s", depart, start_date+"-"+end_date)
// 	// Try cache
// 	if val, err := r.rdb.Get(ctx, cacheKey).Result(); err == nil {
// 		var cached []*biz.DailyAttendanceReport
// 		jsonErr := json.Unmarshal([]byte(val), &cached)
// 		if jsonErr := json.Unmarshal([]byte(val), &cached); jsonErr == nil {
// 			r.log.Infof("✅ Redis cache hit: %s", cacheKey)
// 			return cached, nil
// 		}
// 		r.log.Warnf("⚠️ Redis unmarshal failed for key [%s]: %v", cacheKey, jsonErr)
// 	} else if err != redis.Nil {
// 		r.log.Errorf("❌ Redis GET error for key [%s]: %v", cacheKey, err)

// 	}

// 	// Query attendance
// 	type Result struct {
// 		UserID   string
// 		DeviceIP string
// 		Tgl      string
// 		ClockIn  string
// 		ClockOut string
// 	}
// 	var results []Result

// 	// Ambil employers
// 	empsResp, err := r.employersClient.GetEmployersFilterDepartCode(ctx, &empv1.GetEmployersFilterDepartCodeRequest{
// 		Departcode: depart,
// 	})
// 	if err != nil {
// 		return nil, fmt.Errorf("failed to get employers: %w", err)
// 	}
// 	if len(empsResp.Result) == 0 {
// 		return []*biz.DailyAttendanceReport{}, nil
// 	}

// 	karyaCodes := extractKaryaCodes(empsResp.Result)
// 	companyResp, err := r.employersClient.GetPerusahaan(ctx, &empv1.GetPerusahaanRequest{
// 		Departcode: depart,
// 	})
// 	if err != nil {
// 		return nil, fmt.Errorf("failed to get employers: %w", err)
// 	}
// 	if len(companyResp.Perusahaan) == 0 {
// 		return []*biz.DailyAttendanceReport{}, nil
// 	}

// 	companys := extractKodePerusahaan(companyResp.Perusahaan)

// 	startTime := time.Now()
// 	err = r.data.db.
// 		Table("attendance_log").
// 		Select([]string{
// 			"user_id",
// 			"device_ip",
// 			"TO_CHAR(att_log::date, 'YYYY-MM-DD') AS tgl",
// 			"TO_CHAR(MIN(att_log) FILTER (WHERE status = 0), 'HH24:MI') AS clock_in",
// 			"TO_CHAR(MAX(att_log) FILTER (WHERE status = 1), 'HH24:MI') AS clock_out",
// 		}).
// 		Where("user_id IN ?", karyaCodes).
// 		Where("att_log::date BETWEEN ? AND ?", start_date, end_date).
// 		Group("user_id, device_ip, att_log::date").
// 		Order("user_id, att_log::date").
// 		Scan(&results).Error
// 	r.log.Infof("🐘 Query executed in %s", time.Since(startTime))
// 	if err != nil {
// 		return nil, fmt.Errorf("gorm query error: %w", err)
// 	}

// 	// kodePeru := extractKodePerusahaan(empsResp.Result)

// 	// kodeCab := extractKodeCabang(empsResp.Result)

// }

// func (r *attendanceRawRepo) GetAttendanceDayli(ctx context.Context, dept, start, end string) ([]*biz.DailyAttendanceReport, error) {
// 	if dept == "" {
// 		return nil, fmt.Errorf("depart code cannot be empty")
// 	}
// 	if start == "" || end == "" {
// 		return nil, fmt.Errorf("start and end date cannot be empty")
// 	}

// 	cacheKey := fmt.Sprintf("attendance:daily:%s:%s-%s", dept, start, end)

// 	// Cek Redis
// 	if val, err := r.rdb.Get(ctx, cacheKey).Result(); err == nil {
// 		var cached []*biz.DailyAttendanceReport
// 		if err := json.Unmarshal([]byte(val), &cached); err == nil {
// 			r.log.Infof("✅ Redis cache hit: %s", cacheKey)
// 			return cached, nil
// 		}
// 		r.log.Warnf("⚠️ Redis unmarshal failed [%s]: %v", cacheKey, err)
// 	} else if err != redis.Nil {
// 		r.log.Errorf("❌ Redis GET error [%s]: %v", cacheKey, err)
// 	}

// 	// Ambil employers dari departemen
// 	empsResp, err := r.employersClient.GetEmployersFilterDepartCode(ctx, &empv1.GetEmployersFilterDepartCodeRequest{
// 		Departcode: dept,
// 	})
// 	if err != nil {
// 		return nil, fmt.Errorf("failed to get employers: %w", err)
// 	}
// 	if len(empsResp.Result) == 0 {
// 		return []*biz.DailyAttendanceReport{}, nil
// 	}

// 	karyaCodes := extractKaryaCodes(empsResp.Result)
// 	kodePeru := extractKodePerusahaan(empsResp.Result)
// 	kodeCab := extractKodeCabang(empsResp.Result)
// 	// log.Debug("INI KODE PER DAN CAB", kodePeru[0], kodeCab[0])
// 	// Ambil info perusahaan dan cabang
// 	perResp, err := r.orgV1Client.GetPerusahaan(ctx, &orgv1.GetPerusahaanRequest{
// 		KodePerusahaan: "SGN",
// 	})
// 	if err != nil || perResp == nil {
// 		return nil, fmt.Errorf("gagal ambil data perusahaan: %w", err)
// 	}

// 	// Panggil cabang
// 	cabangResp, err := r.orgV1Client.GetCabang(ctx, &orgv1.GetCabangRequest{
// 		KodeCabang: "S33",
// 	})
// 	if err != nil || cabangResp == nil {
// 		return nil, fmt.Errorf("gagal ambil data cabang: %w", err)
// 	}
// 	// Query attendance
// 	type Result struct {
// 		UserID   string
// 		DeviceIP string
// 		Tgl      string
// 		ClockIn  string
// 		ClockOut string
// 	}
// 	var results []Result

// 	startTime := time.Now()
// 	err = r.data.db.
// 		Table("attendance_log").
// 		Select([]string{
// 			"user_id",
// 			"device_ip",
// 			"TO_CHAR(att_log::date, 'YYYY-MM-DD') AS tgl",
// 			"TO_CHAR(MIN(att_log) FILTER (WHERE status = 0), 'HH24:MI') AS clock_in",
// 			"TO_CHAR(MAX(att_log) FILTER (WHERE status = 1), 'HH24:MI') AS clock_out",
// 		}).
// 		Where("user_id IN ?", karyaCodes).
// 		Where("att_log::date BETWEEN ? AND ?", start, end).
// 		Group("user_id, device_ip, att_log::date").
// 		Order("user_id, att_log::date").
// 		Scan(&results).Error
// 	r.log.Infof("🐘 Query executed in %s", time.Since(startTime))
// 	if err != nil {
// 		return nil, fmt.Errorf("gorm query error: %w", err)
// 	}

// 	// Map employer
// 	employerMap := make(map[string]*empv1.EmployerItem)
// 	for _, emp := range empsResp.Result {
// 		employerMap[strings.TrimSpace(emp.KaryaCode)] = emp
// 	}

// 	// Build data attendance
// 	dataMap := make(map[string][]biz.DailyAttendance)
// 	for _, row := range results {
// 		tglParsed, err := time.Parse("2006-01-02", row.Tgl)
// 		if err != nil {
// 			r.log.Warnf("⚠️ Invalid date: %s", row.Tgl)
// 			continue
// 		}
// 		emp := employerMap[strings.TrimSpace(row.UserID)]
// 		dataMap[emp.GetKaryaName()] = append(dataMap[emp.GetKaryaName()], biz.DailyAttendance{
// 			KaryaCode:  row.UserID,
// 			KaryaName:  safeStr(emp.GetKaryaName()),
// 			Department: safeStr(emp.GetDepartment()),
// 			Tgl:        row.Tgl,
// 			Hari:       localizeDayToIndo(tglParsed.Weekday()),
// 			ClockIn:    row.ClockIn,
// 			ClockOut:   row.ClockOut,
// 			DeviceIP:   row.DeviceIP,
// 		})
// 	}

// 	// Build report per employer
// 	var reports []*biz.DailyAttendanceReport
// 	for _, emp := range empsResp.Result {
// 		reports = append(reports, &biz.DailyAttendanceReport{
// 			KodePerusahaan: kodePeru[0],
// 			NamaPerusahaan: perResp.Result.GetKodePerusahaan(),
// 			KodeCabang:     kodeCab[0],
// 			Cabang:         cabangResp.Result.GetCabang(),
// 			Nama:           safeStr(emp.GetKaryaName()),
// 			Jabatan:        safeStr(emp.GetDepartment()),
// 			Periode:        fmt.Sprintf("%s - %s", start, end),
// 			DibuatOleh:     "Suroso", // dari Keycloak nantinya
// 			DiperiksaOleh:  "Admin",
// 			DisetujuiOleh:  "Admin",
// 			Data:           dataMap[safeStr(emp.GetKaryaName())],
// 		})
// 	}

// 	// Simpan ke Redis
// 	if len(reports) > 0 {
// 		if bytes, err := json.Marshal(reports); err == nil {
// 			if setErr := r.rdb.Set(ctx, cacheKey, bytes, 3*time.Minute).Err(); setErr != nil {
// 				r.log.Warnf("⚠️ Redis SET error [%s]: %v", cacheKey, setErr)
// 			}
// 		} else {
// 			r.log.Warnf("⚠️ Failed to marshal daily attendance: %v", err)
// 		}
// 	}

// 	return reports, nil
// }

// func (r *attendanceRawRepo) GetAttendanceDayli(ctx context.Context, dept, start, end string) ([]*biz.DailyAttendanceReport, error) {
// 	if dept == "" {
// 		return nil, fmt.Errorf("depart code cannot be empty")
// 	}
// 	if start == "" || end == "" {
// 		return nil, fmt.Errorf("start and end date cannot be empty")
// 	}

// 	cacheKey := fmt.Sprintf("attendance:daily:%s:%s-%s", dept, start, end)

// 	if val, err := r.rdb.Get(ctx, cacheKey).Result(); err == nil {
// 		var cached []*biz.DailyAttendanceReport
// 		if err := json.Unmarshal([]byte(val), &cached); err == nil {
// 			r.log.Infof("✅ Redis cache hit: %s", cacheKey)
// 			return cached, nil
// 		}
// 		r.log.Warnf("⚠️ Redis unmarshal failed [%s]: %v", cacheKey, err)
// 	} else if err != redis.Nil {
// 		r.log.Errorf("❌ Redis GET error [%s]: %v", cacheKey, err)
// 	}

// 	log.Debug("INI PARAM :", dept, start, end)

// 	empsResp, err := r.employersClient.GetEmployersFilterDepartCode(ctx, &empv1.GetEmployersFilterDepartCodeRequest{
// 		Departcode: dept,
// 	})
// 	if err != nil {
// 		return nil, fmt.Errorf("failed to get employers: %w", err)
// 	}
// 	if len(empsResp.Result) == 0 {
// 		return []*biz.DailyAttendanceReport{}, nil
// 	}

// 	karyaCodes := extractKaryaCodes(empsResp.Result)
// 	KodePeru := extractKodePerusahaan(empsResp.Result)
// 	kodeCab := extractKodeCabang(empsResp.Result)
// 	perResp, err := r.orgV1Client.GetPerusahaan(ctx, &orgv1.GetPerusahaanRequest{
// 		KodePerusahaan: KodePeru[0],
// 	})
// 	cabangResp, err := r.orgV1Client.GetCabang(ctx, &orgv1.GetCabangRequest{
// 		KodeCabang: kodeCab[0],
// 	})

// 	// SQL
// 	type Result struct {
// 		UserID   string
// 		DeviceIP string
// 		Tgl      string
// 		ClockIn  string
// 		ClockOut string
// 	}
// 	var results []Result

// 	startTime := time.Now()
// 	err = r.data.db.
// 		Table("attendance_log").
// 		Select([]string{
// 			"user_id",
// 			"device_ip",
// 			"TO_CHAR(att_log::date, 'YYYY-MM-DD') AS tgl",
// 			"TO_CHAR(MIN(att_log) FILTER (WHERE status = 0), 'HH24:MI') AS clock_in",
// 			"TO_CHAR(MAX(att_log) FILTER (WHERE status = 1), 'HH24:MI') AS clock_out",
// 		}).
// 		Where("user_id IN ?", karyaCodes).
// 		Where("att_log::date BETWEEN ? AND ?", start, end).
// 		Group("user_id, device_ip, att_log::date").
// 		Order("user_id, att_log::date").
// 		Scan(&results).Error
// 	r.log.Infof("🐘 Query executed in %s", time.Since(startTime))

// 	if err != nil {
// 		return nil, fmt.Errorf("gorm query error: %w", err)
// 	}

// 	employerMap := make(map[string]*empv1.EmployerItem)
// 	for _, emp := range empsResp.Result {
// 		employerMap[strings.TrimSpace(emp.KaryaCode)] = emp
// 	}

// 	// perusahaanMap := make(map[string]*peruV1.PerusahaanResponse)

// 	var mapped []*biz.DailyAttendanceReport

// 	for _, row := range results {
// 		tglParsed, err := time.Parse("2006-01-02", row.Tgl)
// 		if err != nil {
// 			r.log.Warnf("⚠️ Invalid date: %s", row.Tgl)
// 			continue
// 		}
// 		emp := employerMap[strings.TrimSpace(row.UserID)]
// 		mapped = append(mapped, &biz.DailyAttendance{
// 			KaryaCode:  row.UserID,
// 			KaryaName:  safeStr(emp.GetKaryaName()),
// 			Department: safeStr(emp.GetDepartment()),
// 			Tgl:        row.Tgl,
// 			Hari:       localizeDayToIndo(tglParsed.Weekday()),
// 			ClockIn:    row.ClockIn,
// 			ClockOut:   row.ClockOut,
// 			DeviceIP:   row.DeviceIP,
// 		})
// 	}

// 	if len(mapped) > 0 {
// 		if bytes, err := json.Marshal(mapped); err == nil {
// 			if setErr := r.rdb.Set(ctx, cacheKey, bytes, 3*time.Minute).Err(); setErr != nil {
// 				r.log.Warnf("⚠️ Redis SET error [%s]: %v", cacheKey, setErr)
// 			}
// 		} else {
// 			r.log.Warnf("⚠️ Failed to marshal daily attendance: %v", err)
// 		}
// 	}

// 	return mapped, nil
// }

func localizeDayToIndo(day time.Weekday) string {
	switch day {
	case time.Monday:
		return "Senin"
	case time.Tuesday:
		return "Selasa"
	case time.Wednesday:
		return "Rabu"
	case time.Thursday:
		return "Kamis"
	case time.Friday:
		return "Jumat"
	case time.Saturday:
		return "Sabtu"
	case time.Sunday:
		return "Minggu"
	default:
		return ""
	}
}

// func (r *attendancerawRepo) GetAttendanceDayli(
// 	ctx context.Context,
// 	dept, start, end string,
// ) ([]*biz.DailyAttendance, error) {
// 	if len(dept) == 0 {
// 		return nil, fmt.Errorf("depart code cannot be empty")
// 	}

// 	// 🔑 Buat cache key
// 	cacheKey := fmt.Sprintf(
// 		"attendance:filter:%s:start:%s:end:%s",
// 		dept,
// 		start,
// 		end,
// 	)

// 	// 🔄 Coba ambil dari Redis cache
// 	if val, err := r.rdb.Get(ctx, cacheKey).Result(); err == nil {
// 		var cached []*biz.DailyAttendance
// 		if err := json.Unmarshal([]byte(val), &cached); err == nil {
// 			r.log.Infof("✅ Redis cache hit: %s", cacheKey)
// 			return cached, nil
// 		}
// 		r.log.Warnf("⚠️ Failed to unmarshal Redis value [%s]: %v", cacheKey, err)
// 	} else if err != redis.Nil {
// 		r.log.Errorf("❌ Redis GET error for key [%s]: %v", cacheKey, err)
// 	}

// 	// 🔍 SQL Result Struct
// 	type Result struct {
// 		UserID   string
// 		DeviceIP string
// 		Tgl      string
// 		ClockIn  string
// 		ClockOut string
// 	}
// 	var results []Result

// 	// 🐘 Jalankan query GORM
// 	startTime := time.Now()
// 	err := r.data.db.
// 		Table("attendance_log").
// 		Select([]string{
// 			"user_id",
// 			"device_ip",
// 			"TO_CHAR(att_log::date, 'YYYY-MM-DD') AS tgl",
// 			"TO_CHAR(MIN(att_log) FILTER (WHERE status = 0), 'HH24:MI') AS clock_in",
// 			"TO_CHAR(MAX(att_log) FILTER (WHERE status = 1), 'HH24:MI') AS clock_out",
// 		}).
// 		Where("depart_code ?", dept).
// 		Where("att_log::date BETWEEN ? AND ?", start, end).
// 		Group("user_id, device_ip, att_log::date").
// 		Order("user_id, att_log::date").
// 		Scan(&results).Error

// 	elapsed := time.Since(startTime)
// 	if err != nil {
// 		return nil, fmt.Errorf("gorm query error: %w", err)
// 	}
// 	r.log.Infof("🐘 GORM query executed in %s, result count: %d", elapsed, len(results))

// 	// 🚀 Step: Ambil semua employer sekaligus
// 	employers, err := r.employersClient.GetEmployersByFilter(ctx, &empv1.GetEmployersByFilterRequest{KaryaCodes: karyacodes})
// 	if err != nil {
// 		return nil, fmt.Errorf("failed to get employers batch: %w", err)
// 	}

// 	// 🔧 Build map KaryaCode -> EmployerItem
// 	employerMap := make(map[string]*empv1.EmployerItem)
// 	for _, emp := range employers {
// 		code := strings.TrimSpace(emp.KaryaCode)
// 		employerMap[code] = emp
// 	}

// 	// 🎯 Mapping ke biz.DailyAttendance
// 	var mapped []*biz.DailyAttendance
// 	for _, row := range results {
// 		tglParsed, err := time.Parse("2006-01-02", row.Tgl)
// 		if err != nil {
// 			r.log.Warnf("⚠️ Invalid date [%s]: %v", row.Tgl, err)
// 			continue
// 		}

// 		emp := employerMap[row.UserID]
// 		karyaName := ""
// 		department := ""

// 		if emp != nil {
// 			karyaName = strings.TrimSpace(emp.KaryaName)
// 			department = strings.TrimSpace(emp.Department) // Langsung dari employer response
// 		}

// 		mapped = append(mapped, &biz.DailyAttendance{
// 			KaryaCode:  row.UserID,
// 			KaryaName:  karyaName,
// 			Department: department,
// 			Tgl:        row.Tgl,
// 			Hari:       localizeDayToIndo(tglParsed.Weekday()),
// 			ClockIn:    row.ClockIn,
// 			ClockOut:   row.ClockOut,
// 			DeviceIP:   row.DeviceIP,
// 		})
// 	}

// 	// 💾 Simpan hasil ke Redis
// 	if bytes, err := json.Marshal(mapped); err == nil {
// 		if setErr := r.rdb.Set(ctx, cacheKey, bytes, 10*time.Minute).Err(); setErr != nil {
// 			r.log.Warnf("⚠️ Failed to set Redis cache [%s]: %v", cacheKey, setErr)
// 		} else {
// 			r.log.Infof("📦 Redis cache set: %s", cacheKey)
// 		}
// 	} else {
// 		r.log.Warnf("⚠️ Failed to marshal result for Redis: %v", err)
// 	}

// 	return mapped, nil
// }

// func (r *attendancerawRepo) GetAttendanceDayli(
// 	ctx context.Context,
// 	karyacodes []string,
// 	dept, start, end string,
// ) ([]*biz.DailyAttendance, error) {
// 	if len(karyacodes) == 0 {
// 		return nil, fmt.Errorf("karyacodes cannot be empty")
// 	}

// 	cacheKey := fmt.Sprintf(
// 		"attendance:filter:%s:dept:%s:start:%s:end:%s",
// 		strings.Join(karyacodes, ","),
// 		dept,
// 		start,
// 		end,
// 	)

// 	// 🔄 Redis cache check
// 	if val, err := r.rdb.Get(ctx, cacheKey).Result(); err == nil {
// 		var cached []*biz.DailyAttendance
// 		if err := json.Unmarshal([]byte(val), &cached); err == nil {
// 			r.log.Infof("✅ Redis cache hit: %s", cacheKey)
// 			return cached, nil
// 		}
// 		r.log.Warnf("⚠️ Failed to unmarshal Redis value [%s]: %v", cacheKey, err)
// 	} else if err != redis.Nil {
// 		r.log.Errorf("❌ Redis GET error for key [%s]: %v", cacheKey, err)
// 	}

// 	// 🔍 Query struct
// 	type Result struct {
// 		UserID   string
// 		DeviceIP string
// 		Tgl      string
// 		ClockIn  string
// 		ClockOut string
// 	}
// 	var results []Result

// 	// 🐘 GORM query
// 	startTime := time.Now()
// 	err := r.data.db.
// 		Table("attendance_log").
// 		Select([]string{
// 			"user_id",
// 			"device_ip",
// 			"TO_CHAR(att_log::date, 'YYYY-MM-DD') AS tgl",
// 			"TO_CHAR(MIN(att_log) FILTER (WHERE status = 0), 'HH24:MI') AS clock_in",
// 			"TO_CHAR(MAX(att_log) FILTER (WHERE status = 1), 'HH24:MI') AS clock_out",
// 		}).
// 		Where("user_id IN ?", karyacodes).
// 		Where("att_log::date BETWEEN ? AND ?", start, end).
// 		Group("user_id, device_ip, att_log::date").
// 		Order("user_id, att_log::date").
// 		Scan(&results).Error

// 	elapsed := time.Since(startTime)
// 	if err != nil {
// 		return nil, fmt.Errorf("gorm query error: %w", err)
// 	}
// 	r.log.Infof("🐘 GORM query executed in %s, result count: %d", elapsed, len(results))

// 	// 📦 Prefetch employers
// 	employerMap := make(map[string]*empv1.EmployerItem)
// 	for _, code := range karyacodes {
// 		employer, err := r.employersClient.GetEmployersByFilter(ctx, code)
// 		if err != nil {
// 			r.log.Warnf("⚠️ Failed to fetch employer for %s: %v", code, err)
// 			continue
// 		}
// 		employerMap[code] = employer
// 	}

// 	// 📦 Prefetch departments
// 	departmentMap := make(map[string]string)
// 	for _, emp := range employerMap {
// 		if emp == nil {
// 			continue
// 		}
// 		deptKode := fmt.Sprintf("%d", emp.)
// 		if _, exists := departmentMap[deptKode]; exists {
// 			continue
// 		}
// 		dept, err := r.data.departmentClient.GetDepartmentCode(ctx, deptKode)
// 		if err != nil {
// 			r.log.Warnf("⚠️ Failed to fetch department for ID %s: %v", deptKode, err)
// 			continue
// 		}
// 		departmentMap[deptKode] = dept.Name
// 	}

// 	// 🎯 Mapping
// 	mapped := make([]*biz.DailyAttendance, 0, len(results))
// 	for _, row := range results {
// 		tglParsed, err := time.Parse("2006-01-02", row.Tgl)
// 		if err != nil {
// 			r.log.Warnf("⚠️ Failed to parse date [%s]: %v", row.Tgl, err)
// 			continue
// 		}

// 		emp := employerMap[row.UserID]
// 		deptName := ""
// 		if emp != nil {
// 			deptName = departmentMap[fmt.Sprintf("%d", emp.DepartmentId)]
// 		}

// 		mapped = append(mapped, &biz.DailyAttendance{
// 			KaryaCode:  row.UserID,
// 			KaryaName:  getOrDefault(emp, func(e *biz.EmployerItem) string { return e.Name }),
// 			Department: deptName,
// 			Tgl:        row.Tgl,
// 			Hari:       localizeDayToIndo(tglParsed.Weekday()),
// 			ClockIn:    row.ClockIn,
// 			ClockOut:   row.ClockOut,
// 			DeviceIP:   row.DeviceIP,
// 		})
// 	}

// 	// 💾 Save to Redis
// 	if bytes, err := json.Marshal(mapped); err == nil {
// 		if setErr := r.rdb.Set(ctx, cacheKey, bytes, 10*time.Minute).Err(); setErr != nil {
// 			r.log.Warnf("⚠️ Failed to set Redis cache [%s]: %v", cacheKey, setErr)
// 		} else {
// 			r.log.Infof("📦 Redis cache set: %s", cacheKey)
// 		}
// 	} else {
// 		r.log.Warnf("⚠️ Failed to marshal result for Redis: %v", err)
// 	}

// 	return mapped, nil
// }

// // ✅ Helper aman ambil field dari pointer
// func getOrDefault[T any](ptr *T, getter func(*T) string) string {
// 	if ptr == nil {
// 		return ""
// 	}
// 	return getter(ptr)
// }

// func (r *attendancerawRepo) GetAttendanceDayli(
// 	ctx context.Context,
// 	karyacodes []string,
// 	dept, start, end string,
// ) ([]*biz.DailyAttendance, error) {
// 	if len(karyacodes) == 0 {
// 		return nil, fmt.Errorf("karyacodes cannot be empty")
// 	}

// 	cacheKey := fmt.Sprintf(
// 		"attendance:filter:%s:dept:%s:start:%s:end:%s",
// 		strings.Join(karyacodes, ","),
// 		dept,
// 		start,
// 		end,
// 	)

// 	// 🔄 Redis cache check
// 	if val, err := r.rdb.Get(ctx, cacheKey).Result(); err == nil {
// 		var cached []*biz.DailyAttendance
// 		if err := json.Unmarshal([]byte(val), &cached); err == nil {
// 			r.log.Infof("✅ Redis cache hit: %s", cacheKey)
// 			return cached, nil
// 		}
// 		r.log.Warnf("⚠️ Failed to unmarshal Redis value [%s]: %v", cacheKey, err)
// 	} else if err != redis.Nil {
// 		r.log.Errorf("❌ Redis GET error for key [%s]: %v", cacheKey, err)
// 	}

// 	// 🔍 Query struct
// 	type Result struct {
// 		UserID   string
// 		DeviceIP string
// 		Tgl      string
// 		ClockIn  string
// 		ClockOut string
// 	}
// 	var results []Result

// 	// 🐘 GORM query
// 	startTime := time.Now()
// 	err := r.data.db.
// 		Table("attendance_log").
// 		Select([]string{
// 			"user_id",
// 			"device_ip",
// 			"TO_CHAR(att_log::date, 'YYYY-MM-DD') AS tgl",
// 			"TO_CHAR(MIN(att_log) FILTER (WHERE status = 0), 'HH24:MI') AS clock_in",
// 			"TO_CHAR(MAX(att_log) FILTER (WHERE status = 1), 'HH24:MI') AS clock_out",
// 		}).
// 		Where("user_id IN ?", karyacodes).
// 		Where("att_log::date BETWEEN ? AND ?", start, end).
// 		Group("user_id, device_ip, att_log::date").
// 		Order("user_id, att_log::date").
// 		Scan(&results).Error

// 	elapsed := time.Since(startTime)
// 	if err != nil {
// 		return nil, fmt.Errorf("gorm query error: %w", err)
// 	}
// 	r.log.Infof("🐘 GORM query executed in %s, result count: %d", elapsed, len(results))

// 	// 📦 Prefetch employers
// 	employerMap := make(map[string]*biz.EmployerItem)
// 	for _, code := range karyacodes {
// 		employer, err := r.employersClient.GetEmployer(ctx, code)
// 		if err != nil {
// 			r.log.Warnf("⚠️ Failed to fetch employer for %s: %v", code, err)
// 			continue
// 		}
// 		employerMap[code] = employer
// 	}

// 	// 📦 Prefetch departments
// 	departmentMap := make(map[string]string) // dept_id => dept_name
// 	for _, emp := range employerMap {
// 		deptID := fmt.Sprintf("%d", emp.DepartmentId)
// 		if _, ok := departmentMap[deptID]; ok {
// 			continue // sudah diambil
// 		}
// 		dept, err := r.departmentClient.GetDepartment(ctx, deptID)
// 		if err != nil {
// 			r.log.Warnf("⚠️ Failed to fetch department for ID %s: %v", deptID, err)
// 			continue
// 		}
// 		departmentMap[deptID] = dept.Name
// 	}

// 	// 🎯 Mapping
// 	var mapped []*biz.DailyAttendance
// 	for _, row := range results {
// 		tglParsed, _ := time.Parse("2006-01-02", row.Tgl)

// 		emp := employerMap[row.UserID]
// 		deptName := ""
// 		if emp != nil {
// 			deptName = departmentMap[fmt.Sprintf("%d", emp.DepartmentId)]
// 		}

// 		mapped = append(mapped, &biz.DailyAttendance{
// 			KaryaCode:  row.UserID,
// 			KaryaName:  getOrDefault(emp, func(e *biz.EmployerItem) string { return e.Name }),
// 			Department: deptName,
// 			Tgl:        row.Tgl,
// 			Hari:       localizeDayToIndo(tglParsed.Weekday()),
// 			ClockIn:    row.ClockIn,
// 			ClockOut:   row.ClockOut,
// 			DeviceIP:   row.DeviceIP,
// 		})
// 	}

// 	// 💾 Set ke Redis
// 	if bytes, err := json.Marshal(mapped); err == nil {
// 		if setErr := r.rdb.Set(ctx, cacheKey, bytes, 10*time.Minute).Err(); setErr != nil {
// 			r.log.Warnf("⚠️ Failed to set Redis cache [%s]: %v", cacheKey, setErr)
// 		} else {
// 			r.log.Infof("📦 Redis cache set: %s", cacheKey)
// 		}
// 	} else {
// 		r.log.Warnf("⚠️ Failed to marshal result for Redis: %v", err)
// 	}

// 	return mapped, nil
// }

// // ✅ Helper aman ambil field dari pointer
// func getOrDefault[T any](ptr *T, getter func(*T) string) string {
// 	if ptr == nil {
// 		return ""
// 	}
// 	return getter(ptr)
// }

// func (r *attendancerawRepo) GetAttendanceDayli(ctx context.Context, karyacodes []string, dept, start, end string) ([]*biz.DailyAttendance, error) {
// 	if len(karyacodes) == 0 {
// 		return nil, fmt.Errorf("karyacodes cannot be empty")
// 	}
// 	cacheKey := fmt.Sprintf("attendance:filter:%s:dept:%s:start:%s:end:%s", strings.Join(karyacodes, ","), dept, start, end)
// 	// 🔄 Try Redis Cache
// 	val, err := r.rdb.Get(ctx, cacheKey).Result()
// 	if err == nil {
// 		var cached []*biz.DailyAttendance
// 		if unmarshalErr := json.Unmarshal([]byte(val), &cached); unmarshalErr == nil {
// 			r.log.Infof("✅ Redis cache hit: %s", cacheKey)
// 			return cached, nil
// 		}
// 		r.log.Warnf("⚠️ Redis unmarshal failed for key [%s]: %v", cacheKey, err)
// 	} else if err != redis.Nil {
// 		r.log.Errorf("❌ Redis GET error for key [%s]: %v", cacheKey, err)
// 	}
// 	type Result struct {
// 		UserID   string
// 		DeviceIP string
// 		Tgl      string
// 		ClockIn  string
// 		ClockOut string
// 	}

// 	var results []Result
// 	startTime := time.Now()
// 	err = r.data.db.
// 		Table("attendance_log").
// 		Select([]string{
// 			"user_id",
// 			"device_ip",
// 			"TO_CHAR(att_log::date, 'YYYY-MM-DD') AS tgl",
// 			"TO_CHAR(MIN(att_log) FILTER (WHERE status = 0), 'HH24:MI') AS clock_in",
// 			"TO_CHAR(MAX(att_log) FILTER (WHERE status = 1), 'HH24:MI') AS clock_out",
// 		}).
// 		Where("user_id IN ?", karyacodes).
// 		Where("att_log::date BETWEEN ? AND ?", start, end).
// 		Group("user_id, device_ip, att_log::date").
// 		Order("user_id, att_log::date").
// 		Scan(&results).Error

// 	elapsed := time.Since(startTime)

// 	if err != nil {
// 		return nil, fmt.Errorf("gorm query error: %w", err)
// 	}
// 	r.log.Infof("🐘 GORM query executed in %s, result count: %d", elapsed, len(results))

// 	// 🔄 Convert to biz struct
// 	var mapped []*biz.DailyAttendance
// 	for _, row := range results {
// 		tglParsed, _ := time.Parse("2006-01-02", row.Tgl)
// 		mapped = append(mapped, &biz.DailyAttendance{
// 			KaryaCode: row.UserID,
// 			KaryaName: //ini diisi dr employer microservice ,
// 			Department: ,//ini diisi dr depatement microservice ,
// 			Tgl:      row.Tgl,
// 			Hari:     localizeDayToIndo(tglParsed.Weekday()),
// 			ClockIn:  row.ClockIn,
// 			ClockOut: row.ClockOut,
// 			DeviceIP: row.DeviceIP,
// 		})
// 	}

// 	// 🧠 Set to Redis
// 	if bytes, err := json.Marshal(mapped); err == nil {
// 		if setErr := r.rdb.Set(ctx, cacheKey, bytes, 10*time.Minute).Err(); setErr != nil {
// 			r.log.Warnf("⚠️ Failed to set Redis cache [%s]: %v", cacheKey, setErr)
// 		} else {
// 			r.log.Infof("📦 Redis cache set: %s", cacheKey)
// 		}
// 	} else {
// 		r.log.Warnf("⚠️ Failed to marshal result for Redis: %v", err)
// 	}

// 	return mapped, nil
// }
