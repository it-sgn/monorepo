package biz

import (
	"context"
	"mall-go/pkg/page_token"

	"github.com/go-kratos/kratos/v2/log"
	"golang.org/x/sync/singleflight"

	departV1 "mall-go/api/department/service/v1"
	employersV1 "mall-go/api/employers/service/v1"
)

// Status hadir pulang
type AttStatus struct {
	ClockIn  string `json:"ClockIn"`
	ClockOut string `json:"ClockOut"`
}

// Data per hari per karyawan
type DailyAttendance struct {
	Tanggal   string       `json:"tanggal"`
	KaryaName string       `json:"karyaname"`
	Status    []*AttStatus `json:"Status"`
	Evaluasi  string       `json:"evaluasi"`
}

// Laporan keseluruhan
type DailyAttendanceReport struct {
	NamaPerusahaan string            `json:"NamaPerusahaan"`
	Cabang         string            `json:"Cabang"`
	Department     string            `json:"Department"`
	Jabatan        string            `json:"Jabatan"`
	Periode        string            `json:"Periode"`
	DibuatOleh     string            `json:"DibuatOleh"`
	DiperiksaOleh  string            `json:"DiperiksaOleh"`
	DisetujuiOleh  string            `json:"DisetujuiOleh"`
	Data           []DailyAttendance `json:"Data"`
}

type AttendanceRawRepo interface {
	GetAttendanceReport(ctx context.Context, startDate, endDate, depart string) ([]*DailyAttendanceReport, error)
}

type AttendanceRawUsecase struct {
	repo       AttendanceRawRepo
	pageToken  page_token.ProcessPageTokens
	log        *log.Helper
	sg         singleflight.Group
	deptClient departV1.DepartmentClient
	empClient  employersV1.EmployersClient
}

func NewAttendanceRawUsecase(
	repo AttendanceRawRepo,
	dept departV1.DepartmentClient,
	emp employersV1.EmployersClient,
	logger log.Logger,
) *AttendanceRawUsecase {
	return &AttendanceRawUsecase{
		repo:       repo,
		log:        log.NewHelper(log.With(logger, "module", "usecase/AttendanceRaw")),
		deptClient: dept,
		empClient:  emp,
	}
}

func (uc *AttendanceRawUsecase) GetAttendanceReport(
	ctx context.Context,
	startDate, endDate, depart string,
) ([]*DailyAttendanceReport, error) {
	return uc.repo.GetAttendanceReport(ctx, startDate, endDate, depart)
}
