//go:build wireinject
// +build wireinject

// The build tag makes sure the stub is not built in the final build.

package main

import (
	"mall-go/module/department/service/internal/biz"
	"mall-go/module/department/service/internal/conf"
	"mall-go/module/department/service/internal/data"
	"mall-go/module/department/service/internal/server"
	"mall-go/module/department/service/internal/service" // Import service package

	"github.com/go-kratos/kratos/v2"
	"github.com/go-kratos/kratos/v2/log" // Import registry

	// "github.com/go-kratos/kratos/v2/transport/grpc"
	// "github.com/go-kratos/kratos/v2/transport/http"
	"github.com/google/wire"
)

// wireApp init kratos application.
// Mengembalikan *kratos.App DAN *service.DepartmentService
func wireApp( // <-- PASTIKAN HURUF KAPITAL 'W'
	*conf.Server,
	*conf.Data,
	*conf.Registry,
	log.Logger,
) (*kratos.App, *service.DepartmentService, func(), error) {
	panic(wire.Build(
		server.ProviderSet,
		data.ProviderSet,
		biz.ProviderSet,
		service.ProviderSet,
		newApp,
	))
}

// func newApp(
// 	logger log.Logger,
// 	hs *http.Server,
// 	gs *grpc.Server,
// 	rr registry.Registrar,
// 	departmentSvc *service.DepartmentService, // Terima instance DepartmentService
// ) (*kratos.App, *service.DepartmentService, func(), error) {
// 	app := kratos.New(
// 		kratos.ID("department.service"),
// 		kratos.Name("department.service"),
// 		kratos.Version("1.0"),
// 		kratos.Metadata(map[string]string{}),
// 		kratos.Logger(logger),
// 		kratos.Server(
// 			hs,
// 			gs,
// 		),
// 		kratos.Registrar(rr),
// 	)

// 	// Cleanup function untuk publisher
// 	// Mengakses field Publisher yang sudah diexport
// 	cleanupPublisher := func() {
// 		if departmentSvc != nil && departmentSvc.Publisher != nil { // <-- AKSES Publisher YANG SUDAH DIEXPORT
// 			logger.Log(log.LevelInfo, "msg", "Closing publisher from wire cleanup")
// 			departmentSvc.Publisher.Close() // <-- PANGGIL Close() PADA Publisher
// 		}
// 	}

// 	return app, departmentSvc, cleanupPublisher, nil
// }

// newApp adalah helper fungsi yang akan di-generate oleh wire.
// Ini perlu didefinisikan secara eksplisit di sini agar wire bisa melihatnya.
// Ini adalah versi yang disederhanakan dari newApp di main.go.
// Wire akan menginject dependensi yang dibutuhkan secara otomatis.

// //go:build wireinject
// // +build wireinject

// // The build tag makes sure the stub is not built in the final build.

// package main

// import (
// 	"mall-go/module/department/service/internal/biz"
// 	"mall-go/module/department/service/internal/conf"
// 	"mall-go/module/department/service/internal/data"
// 	"mall-go/module/department/service/internal/server"
// 	"mall-go/module/department/service/internal/service"

// 	"github.com/go-kratos/kratos/v2"
// 	"github.com/go-kratos/kratos/v2/log"
// 	"github.com/google/wire"
// )

// // wireApp init kratos application.
// // func wireApp(*conf.Server, *conf.Data, *conf.Registry, log.Logger) (*kratos.App, func(), error) {
// // 	panic(wire.Build(server.ProviderSet, data.ProviderSet, biz.ProviderSet, service.ProviderSet, newApp))
// // }

// func wireApp(*conf.Server, *conf.Data, *conf.Registry, log.Logger) (*kratos.App, func(), error) {
// 	panic(wire.Build(server.ProviderSet, data.ProviderSet, biz.ProviderSet, service.ProviderSet, newApp))
// }
