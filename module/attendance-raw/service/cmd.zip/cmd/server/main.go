package main

import (
	"context"
	"flag"

	// "net/http"
	"os"
	"time"

	"mall-go/module/department/service/internal/conf"
	"mall-go/module/department/service/internal/service"

	// "mall-go/module/department/service/internal/service" // <-- Import di package

	// Untuk tipe *service.DepartmentService

	"github.com/go-kratos/kratos/v2"
	"github.com/go-kratos/kratos/v2/config"
	"github.com/go-kratos/kratos/v2/config/file"
	"github.com/go-kratos/kratos/v2/log"
	"github.com/go-kratos/kratos/v2/middleware/tracing"
	"github.com/go-kratos/kratos/v2/registry"
	"github.com/go-kratos/kratos/v2/transport/grpc"
	"github.com/go-kratos/kratos/v2/transport/http"
	// "google.golang.org/grpc"
	// "github.com/go-kratos/kratos/v2/registry" // Tidak perlu import di sini jika hanya digunakan di wire.go
	// Tidak perlu import di sini
	// Tidak perlu import di sini
)

// go build -ldflags "-X main.Version=x.y.z"
var (
	Name     string = "department.service"
	Version  string = "1.0"
	flagconf string

	id = Name
)

func init() {
	flag.StringVar(&flagconf, "conf", "../../configs", "config path, eg: -conf config.yaml")
}

// newApp (fungsi ini tidak lagi didefinisikan di sini, karena sudah ada di wire.go untuk Wire)
// Jika Anda menggunakan Kratos versi lama yang tidak memiliki app.Hook,
// maka logic startup akan dipindahkan ke sini.
// Namun, dengan wire, kita bisa memanfaatkan hook di wire.go atau langsung di main.go
// jika app.Hook tersedia.

func newApp(
	logger log.Logger,
	hs *http.Server,
	gs *grpc.Server,
	rr registry.Registrar,
	departmentSvc *service.DepartmentService, // Terima instance DepartmentService
) (*kratos.App, *service.DepartmentService, func(), error) {
	app := kratos.New(
		kratos.ID("department.service"),
		kratos.Name("department.service"),
		kratos.Version("1.0"),
		kratos.Metadata(map[string]string{}),
		kratos.Logger(logger),
		kratos.Server(
			hs,
			gs,
		),
		kratos.Registrar(rr),
	)

	// Cleanup function untuk publisher
	// Mengakses field Publisher yang sudah diexport
	cleanupPublisher := func() {
		if departmentSvc != nil && departmentSvc.Publisher != nil { // <-- AKSES Publisher YANG SUDAH DIEXPORT
			logger.Log(log.LevelInfo, "msg", "Closing publisher from wire cleanup")
			departmentSvc.Publisher.Close() // <-- PANGGIL Close() PADA Publisher
		}
	}

	return app, departmentSvc, cleanupPublisher, nil
}

// func newApp(
// 	logger log.Logger,
// 	hs *http.Server,
// 	gs *grpc.Server,
// 	rr registry.Registrar, // Pastikan registry diinject
// 	departmentSvc *service.DepartmentService, // <-- Terima instance DepartmentService
// ) (*kratos.App, *service.DepartmentService, func(), error) { // <-- TANDA TANGAN DIUBAH DI SINI
// 	app := kratos.New(
// 		kratos.ID("department.service"),
// 		kratos.Name("department.service"),
// 		kratos.Version("1.0"),
// 		kratos.Metadata(map[string]string{}),
// 		kratos.Logger(logger),
// 		kratos.Server(
// 			hs,
// 			gs,
// 		),
// 		kratos.Registrar(rr),
// 	)

// 	// Cleanup function untuk publisher
// 	// Publisher di-inject ke DepartmentService, jadi kita bisa mengaksesnya dari sana.
// 	cleanupPublisher := func() {
// 		if p, ok := departmentSvc.Publisher.(interface{ Close() error }); ok {
// 			logger.Log(log.LevelInfo, "msg", "Closing publisher from wire cleanup")
// 			p.Close()
// 		}
// 	}

// 	return app, departmentSvc, cleanupPublisher, nil // <-- KEMBALIKAN departmentSvc JUGA
// }

func main() {
	flag.Parse()
	logger := log.With(log.NewStdLogger(os.Stdout),
		"ts", log.DefaultTimestamp,
		"caller", log.DefaultCaller,
		"service.id", id,
		"service.name", Name,
		"service.version", Version,
		"trace_id", tracing.TraceID(),
		"span_id", tracing.SpanID(),
	)
	log.SetLogger(logger)

	c := config.New(
		config.WithSource(
			file.NewSource(flagconf),
		),
	)
	defer c.Close()

	if err := c.Load(); err != nil {
		panic(err)
	}

	var bc conf.Bootstrap
	if err := c.Scan(&bc); err != nil {
		panic(err)
	}
	var rc conf.Registry
	if err := c.Scan(&rc); err != nil {
		panic(err)
	}

	// Panggil WireApp (perhatikan huruf kapital 'W')
	// Sekarang mengembalikan app, departmentSvc, dan cleanup function
	// app, departmentSvc, cleanup, err := WireApp(bc.Server, bc.Data, &rc, logger) // <-- PANGGILAN BARU
	app, departmentSvc, cleanup, err := wireApp(bc.Server, bc.Data, &rc, logger)
	if err != nil {
		panic(err)
	}
	defer cleanup() // Cleanup ini akan menutup publisher juga

	// --- MEKANISME STARTUP (Jika app.Hook tidak tersedia atau Anda memilih pendekatan ini) ---
	startupCtx, cancelStartup := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancelStartup()

	go func() {
		time.Sleep(1 * time.Second) // Beri sedikit jeda
		// Panggil metode pada instance departmentSvc yang sudah di-inject
		departmentSvc.PublishServiceReady(startupCtx) // <-- KOREKSI DI SINI
	}()
	// --- AKHIR MEKANISME STARTUP ---

	// start and wait for stop signal
	if err := app.Run(); err != nil {
		panic(err)
	}
}

// package main

// import (
// 	"context"
// 	"flag"
// 	"os"
// 	"time"

// 	"mall-go/module/department/service/internal/conf"

// 	// "mall-go/module/department/service/internal/service"
// 	// eventv1 "mall-go/api/event/v1"

// 	"github.com/go-kratos/kratos/v2/config"
// 	"github.com/go-kratos/kratos/v2/config/file"
// 	"github.com/go-kratos/kratos/v2/log"
// 	"github.com/go-kratos/kratos/v2/middleware/tracing"
// )

// // go build -ldflags "-X main.Version=x.y.z"
// var (
// 	// Name is the name of the compiled software.
// 	Name string = "department.service"
// 	// Version is the version of the compiled software.
// 	Version string = "1.0"
// 	// flagconf is the config flag.
// 	flagconf string

// 	id = Name
// )

// func init() {
// 	flag.StringVar(&flagconf, "conf", "../../configs", "config path, eg: -conf config.yaml")
// }

// // func newApp(logger log.Logger, hs *http.Server, gs *grpc.Server, rr registry.Registrar) *kratos.App {
// // 	return kratos.New(
// // 		kratos.ID(id),
// // 		kratos.Name(Name),
// // 		kratos.Version(Version),
// // 		kratos.Metadata(map[string]string{}),
// // 		kratos.Logger(logger),
// // 		kratos.Server(
// // 			hs,
// // 			gs,
// // 		),
// // 		kratos.Registrar(rr),
// // 	)

// // }

// func main() {
// 	flag.Parse()
// 	logger := log.With(log.NewStdLogger(os.Stdout),
// 		"ts", log.DefaultTimestamp,
// 		"caller", log.DefaultCaller,
// 		"service.id", id,
// 		"service.name", Name,
// 		"service.version", Version,
// 		"trace_id", tracing.TraceID(),
// 		"span_id", tracing.SpanID(),
// 	)
// 	c := config.New(
// 		config.WithSource(
// 			file.NewSource(flagconf),
// 		),
// 	)
// 	defer c.Close()

// 	if err := c.Load(); err != nil {
// 		panic(err)
// 	}

// 	var bc conf.Bootstrap
// 	if err := c.Scan(&bc); err != nil {
// 		panic(err)
// 	}
// 	var rc conf.Registry
// 	if err := c.Scan(&rc); err != nil {
// 		panic(err)
// 	}
// 	app, cleanup, err := wireApp(bc.Server, bc.Data, &rc, logger)
// 	if err != nil {
// 		panic(err)
// 	}
// 	defer cleanup()

// 	// --- MEKANISME STARTUP (Jika app.Hook tidak tersedia atau Anda memilih pendekatan ini) ---
// 	startupCtx, cancelStartup := context.WithTimeout(context.Background(), 5*time.Second)
// 	defer cancelStartup()

// 	go func() {
// 		time.Sleep(1 * time.Second) // Beri sedikit jeda
// 		// Panggil metode pada instance departmentSvc yang sudah di-inject
// 		departmentSvc.PublishServiceReady(startupCtx) // <-- KOREKSI DI SINI
// 	}()
// 	// --- AKHIR MEKANISME STARTUP ---

// 	// start and wait for stop signal
// 	if err := app.Run(); err != nil {
// 		panic(err)
// 	}
// }
